import { useState, useEffect } from "react";
import { useSearch } from "wouter";
import { motion } from "framer-motion";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import SwingLayout from "@/components/SwingLayout";
import { Link } from "wouter";
import {
  Zap, Target, RotateCcw, Clock, Crown, ChevronRight,
  TrendingUp, AlertTriangle, CheckCircle2, Info, Upload, ChevronDown
} from "lucide-react";

const fadeUp = {
  hidden: { opacity: 0, y: 20 },
  visible: (i: number) => ({ opacity: 1, y: 0, transition: { duration: 0.4, delay: i * 0.08 } }),
};

function ScoreRing({ score, label, color }: { score: number; label: string; color: string }) {
  const circumference = 2 * Math.PI * 36;
  const offset = circumference - (score / 100) * circumference;
  return (
    <div className="flex flex-col items-center gap-2">
      <div className="relative w-24 h-24">
        <svg className="w-24 h-24 -rotate-90" viewBox="0 0 80 80">
          <circle cx="40" cy="40" r="36" fill="none" stroke="oklch(0.22 0.015 260)" strokeWidth="6" />
          <circle cx="40" cy="40" r="36" fill="none" stroke={color} strokeWidth="6"
            strokeDasharray={circumference} strokeDashoffset={offset}
            strokeLinecap="round" className="transition-all duration-1000" />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="font-display font-bold text-xl text-foreground">{score}</span>
        </div>
      </div>
      <span className="text-xs text-muted-foreground text-center">{label}</span>
    </div>
  );
}

function MetricBar({ label, value, max = 100, unit = "", color, note, index }: {
  label: string; value: number; max?: number; unit?: string; color: string; note?: string; index: number;
}) {
  const pct = Math.min((value / max) * 100, 100);
  const getLevel = (p: number) => p >= 80 ? { text: "Excellent", icon: CheckCircle2, cls: "text-primary" }
    : p >= 60 ? { text: "Good", icon: TrendingUp, cls: "text-blue-400" }
    : { text: "Needs Work", icon: AlertTriangle, cls: "text-orange-400" };
  const level = getLevel(pct);

  return (
    <motion.div custom={index} variants={fadeUp} initial="hidden" animate="visible"
      className="bg-card border border-white/5 rounded-xl p-4 hover:border-primary/20 transition-all">
      <div className="flex items-center justify-between mb-3">
        <div>
          <p className="font-medium text-foreground text-sm">{label}</p>
          {note && <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed max-w-sm">{note}</p>}
        </div>
        <div className="text-right shrink-0 ml-4">
          <span className="font-display font-bold text-2xl text-foreground">{value}</span>
          <span className="text-sm text-muted-foreground">{unit}</span>
          <div className={`flex items-center gap-1 justify-end mt-0.5 ${level.cls}`}>
            <level.icon className="w-3 h-3" />
            <span className="text-xs">{level.text}</span>
          </div>
        </div>
      </div>
      <div className="w-full bg-secondary rounded-full h-2">
        <motion.div className="h-2 rounded-full" style={{ background: color }}
          initial={{ width: 0 }} animate={{ width: `${pct}%` }} transition={{ duration: 0.8, delay: index * 0.1 }} />
      </div>
    </motion.div>
  );
}

function LockedMetric({ label }: { label: string }) {
  return (
    <div className="relative bg-card border border-white/5 rounded-xl p-4 overflow-hidden">
      <div className="absolute inset-0 bg-background/70 backdrop-blur-[2px] z-10 flex items-center justify-between px-4">
        <div className="flex items-center gap-2">
          <Crown className="w-4 h-4 text-primary" />
          <span className="text-sm font-medium text-foreground">Pro Feature</span>
        </div>
        <Link href="/dashboard/settings?tab=billing" className="no-underline">
          <Button size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90 text-xs h-7 px-3">
            Upgrade
          </Button>
        </Link>
      </div>
      <div className="opacity-20">
        <p className="font-medium text-foreground text-sm mb-2">{label}</p>
        <div className="w-full bg-secondary rounded-full h-2">
          <div className="h-2 rounded-full bg-primary w-3/4" />
        </div>
      </div>
    </div>
  );
}

export default function AnalysisPage() {
  const search = useSearch();
  const params = new URLSearchParams(search);
  const sessionIdParam = params.get("session");
  const { user } = useAuth();
  const isPro = (user as any)?.plan === "pro" || (user as any)?.plan === "team";

  const { data: sessions } = trpc.sessions.list.useQuery();
  const [selectedId, setSelectedId] = useState<number | null>(sessionIdParam ? parseInt(sessionIdParam) : null);

  useEffect(() => {
    if (!selectedId && sessions && sessions.length > 0) {
      setSelectedId(sessions[0].id);
    }
  }, [sessions, selectedId]);

  const { data: analysis, isLoading } = trpc.analysis.getBySession.useQuery(
    { sessionId: selectedId! },
    { enabled: !!selectedId }
  );

  const selectedSession = sessions?.find(s => s.id === selectedId);

  return (
    <SwingLayout>
      <div className="max-w-4xl mx-auto space-y-6">
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div>
              <h1 className="font-display text-2xl lg:text-3xl font-bold text-foreground mb-1">AI Analysis</h1>
              <p className="text-muted-foreground">Detailed breakdown of your swing mechanics.</p>
            </div>
            <Link href="/dashboard/upload" className="no-underline">
              <Button variant="outline" className="border-border text-foreground hover:bg-secondary">
                <Upload className="w-4 h-4 mr-2" /> New Upload
              </Button>
            </Link>
          </div>
        </motion.div>

        {/* Session selector */}
        {sessions && sessions.length > 0 && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.1 }}
            className="bg-card border border-white/5 rounded-xl p-4">
            <div className="flex items-center gap-3 flex-wrap">
              <span className="text-sm text-muted-foreground shrink-0">Session:</span>
              <div className="flex gap-2 flex-wrap">
                {sessions.slice(0, 6).map((s) => (
                  <button key={s.id} onClick={() => setSelectedId(s.id)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                      selectedId === s.id
                        ? "bg-primary/20 text-primary border border-primary/30"
                        : "bg-secondary/40 text-muted-foreground hover:text-foreground border border-transparent"
                    }`}>
                    {s.title}
                  </button>
                ))}
              </div>
            </div>
          </motion.div>
        )}

        {/* No sessions */}
        {!sessions?.length && (
          <div className="text-center py-16 bg-card border border-white/5 rounded-2xl">
            <Upload className="w-12 h-12 text-muted-foreground/40 mx-auto mb-4" />
            <p className="font-display font-semibold text-foreground mb-2">No sessions yet</p>
            <p className="text-muted-foreground text-sm mb-6">Upload your first swing video to see your AI analysis.</p>
            <Link href="/dashboard/upload" className="no-underline">
              <Button className="bg-primary text-primary-foreground hover:bg-primary/90">Upload Now</Button>
            </Link>
          </div>
        )}

        {selectedId && (
          <>
            {/* Video playback */}
            {selectedSession?.videoUrl && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.15 }}
                className="bg-card border border-white/5 rounded-2xl overflow-hidden">
                <video src={selectedSession.videoUrl} controls className="w-full max-h-80 object-contain bg-black" />
                <div className="p-4 flex items-center justify-between">
                  <div>
                    <p className="font-medium text-foreground text-sm">{selectedSession.title}</p>
                    <p className="text-xs text-muted-foreground">
                      {new Date(selectedSession.createdAt).toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" })}
                    </p>
                  </div>
                  <Badge className="bg-primary/15 text-primary border-primary/20">
                    <CheckCircle2 className="w-3 h-3 mr-1" /> Analyzed
                  </Badge>
                </div>
              </motion.div>
            )}

            {/* No video placeholder */}
            {!selectedSession?.videoUrl && selectedSession && (
              <div className="bg-card border border-white/5 rounded-2xl p-6 text-center">
                <div className="w-full h-48 bg-secondary/30 rounded-xl flex items-center justify-center mb-4">
                  <div className="text-center">
                    <div className="w-12 h-12 rounded-full bg-primary/15 flex items-center justify-center mx-auto mb-2">
                      <Zap className="w-6 h-6 text-primary" />
                    </div>
                    <p className="text-sm text-muted-foreground">Video preview available after upload</p>
                  </div>
                </div>
              </div>
            )}

            {isLoading ? (
              <div className="space-y-3">
                {[1, 2, 3, 4].map(i => <div key={i} className="h-20 bg-card rounded-xl animate-pulse" />)}
              </div>
            ) : analysis ? (
              <>
                {/* Score overview */}
                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
                  className="bg-card border border-white/5 rounded-2xl p-6">
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="font-display font-semibold text-foreground">Overall Score</h2>
                    <div className="flex items-center gap-2">
                      <span className="font-display font-bold text-3xl text-primary">
                        {Math.round(analysis.overallScore ?? 0)}
                      </span>
                      <span className="text-muted-foreground text-sm">/100</span>
                    </div>
                  </div>
                  <div className="flex flex-wrap justify-around gap-6">
                    <ScoreRing score={Math.round(analysis.batSpeedScore ?? 0)} label="Bat Speed" color="oklch(0.65 0.22 145)" />
                    <ScoreRing score={Math.round(analysis.swingEfficiency ?? 0)} label="Swing Efficiency" color="oklch(0.60 0.20 200)" />
                    <ScoreRing score={Math.round(analysis.hipRotation ?? 0)} label="Hip Rotation" color="oklch(0.70 0.18 55)" />
                    <ScoreRing score={Math.round(analysis.batLagScore ?? 0)} label="Bat Lag" color="oklch(0.65 0.20 300)" />
                  </div>
                </motion.div>

                {/* Detailed metrics */}
                <div className="space-y-3">
                  <h2 className="font-display font-semibold text-foreground">Detailed Metrics</h2>

                  <MetricBar index={0} label="Bat Speed Score" value={Math.round(analysis.batSpeedScore ?? 0)}
                    color="oklch(0.65 0.22 145)" />

                  <MetricBar index={1} label="Swing Efficiency" value={Math.round(analysis.swingEfficiency ?? 0)}
                    unit="%" color="oklch(0.60 0.20 200)" />

                  {isPro ? (
                    <>
                      <MetricBar index={2} label="Hip Rotation" value={Math.round(analysis.hipRotation ?? 0)}
                        unit="%" note={analysis.hipRotationNotes ?? undefined}
                        color="oklch(0.70 0.18 55)" />
                      <MetricBar index={3} label="Bat Lag Timing" value={Math.round(analysis.batLagScore ?? 0)}
                        note={analysis.batLagNotes ?? undefined}
                        color="oklch(0.65 0.20 300)" />
                    </>
                  ) : (
                    <>
                      <LockedMetric label="Hip Rotation Analysis" />
                      <LockedMetric label="Bat Lag Timing" />
                    </>
                  )}
                </div>

                {/* Body positioning notes */}
                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}
                  className="bg-card border border-white/5 rounded-2xl p-5">
                  <div className="flex items-center gap-2 mb-3">
                    <Info className="w-4 h-4 text-blue-400" />
                    <h3 className="font-display font-semibold text-foreground">Body Positioning Notes</h3>
                  </div>
                  <p className="text-sm text-foreground/80 leading-relaxed">{analysis.bodyPositioningNotes}</p>
                </motion.div>

                {/* Recommendations */}
                {isPro && analysis.recommendations && (
                  <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}
                    className="bg-card border border-white/5 rounded-2xl p-5">
                    <h3 className="font-display font-semibold text-foreground mb-4">Recommended Drills</h3>
                    <div className="space-y-2">
                      {(analysis.recommendations as string[]).map((rec, i) => (
                        <div key={i} className="flex items-start gap-3 p-3 bg-secondary/20 rounded-lg">
                          <div className="w-5 h-5 rounded-full bg-primary/20 flex items-center justify-center shrink-0 mt-0.5">
                            <span className="text-xs font-bold text-primary">{i + 1}</span>
                          </div>
                          <p className="text-sm text-foreground/80">{rec}</p>
                        </div>
                      ))}
                    </div>
                  </motion.div>
                )}

                {/* Upgrade CTA for free users */}
                {!isPro && (
                  <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}
                    className="bg-primary/5 border border-primary/20 rounded-2xl p-5 flex items-center justify-between gap-4 flex-wrap">
                    <div className="flex items-center gap-3">
                      <Crown className="w-5 h-5 text-primary shrink-0" />
                      <div>
                        <p className="font-semibold text-foreground text-sm">Unlock Full Analysis</p>
                        <p className="text-xs text-muted-foreground">Get hip rotation, bat lag, body positioning details, and drill recommendations.</p>
                      </div>
                    </div>
                    <Link href="/dashboard/settings?tab=billing" className="no-underline">
                      <Button className="bg-primary text-primary-foreground hover:bg-primary/90 shrink-0">
                        Upgrade to Pro <ChevronRight className="w-4 h-4 ml-1" />
                      </Button>
                    </Link>
                  </motion.div>
                )}
              </>
            ) : (
              <div className="text-center py-12 bg-card border border-white/5 rounded-2xl">
                <Zap className="w-10 h-10 text-muted-foreground/40 mx-auto mb-3" />
                <p className="text-muted-foreground text-sm">No analysis found for this session.</p>
                <p className="text-xs text-muted-foreground/60 mt-1">The session may still be processing.</p>
              </div>
            )}
          </>
        )}
      </div>
    </SwingLayout>
  );
}

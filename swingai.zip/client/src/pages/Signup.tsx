import { motion } from "framer-motion";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { getLoginUrl } from "@/const";
import { Zap, ArrowLeft, Check } from "lucide-react";

function GoogleIcon() {
  return (
    <svg viewBox="0 0 24 24" className="w-5 h-5" fill="none">
      <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
      <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
      <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
      <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
    </svg>
  );
}

function AppleIcon() {
  return (
    <svg viewBox="0 0 24 24" className="w-5 h-5 fill-foreground">
      <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.8-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z"/>
    </svg>
  );
}

const perks = [
  "3 free swing analyses every month",
  "Bat speed & swing efficiency scores",
  "No credit card required",
  "Upgrade or cancel anytime",
];

export default function Signup() {
  const loginUrl = getLoginUrl();

  return (
    <div className="min-h-screen bg-background flex">
      {/* Left panel */}
      <div className="hidden lg:flex lg:w-1/2 relative overflow-hidden bg-card border-r border-white/5">
        <div className="absolute inset-0 grid-bg opacity-30" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] rounded-full"
          style={{ background: "radial-gradient(ellipse, oklch(0.65 0.22 145 / 0.15) 0%, transparent 70%)" }} />
        <div className="relative z-10 flex flex-col justify-between p-12 w-full">
          <Link href="/" className="flex items-center gap-2 no-underline">
            <div className="w-9 h-9 rounded-xl bg-primary flex items-center justify-center">
              <Zap className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="font-display font-bold text-xl text-foreground">SwingAI</span>
          </Link>

          <div>
            <motion.h2
              initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}
              className="font-display text-4xl font-bold text-foreground mb-4">
              Start your free<br />
              <span className="text-gradient">training journey</span>
            </motion.h2>
            <motion.p
              initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.1 }}
              className="text-muted-foreground text-lg mb-8">
              Get instant AI feedback on your swing mechanics. No equipment needed.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.2 }}
              className="space-y-3">
              {perks.map((perk) => (
                <div key={perk} className="flex items-center gap-3">
                  <div className="w-5 h-5 rounded-full bg-primary/20 flex items-center justify-center shrink-0">
                    <Check className="w-3 h-3 text-primary" />
                  </div>
                  <span className="text-sm text-foreground/80">{perk}</span>
                </div>
              ))}
            </motion.div>
          </div>

          <p className="text-xs text-muted-foreground">© 2026 Ronyzap LLC. All rights reserved.</p>
        </div>
      </div>

      {/* Right panel */}
      <div className="flex-1 flex items-center justify-center p-6">
        <motion.div
          initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.5 }}
          className="w-full max-w-md">

          <Link href="/" className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors mb-8 no-underline">
            <ArrowLeft className="w-4 h-4" /> Back to home
          </Link>

          <div className="mb-8">
            <div className="lg:hidden flex items-center gap-2 mb-6">
              <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
                <Zap className="w-4 h-4 text-primary-foreground" />
              </div>
              <span className="font-display font-bold text-lg text-foreground">SwingAI</span>
            </div>
            <h1 className="font-display text-3xl font-bold text-foreground mb-2">Create your account</h1>
            <p className="text-muted-foreground">Start analyzing your swing in minutes. Free forever.</p>
          </div>

          {/* Social signup */}
          <div className="space-y-3 mb-6">
            <a href={loginUrl} className="block">
              <Button variant="outline" className="w-full h-11 border-border bg-secondary/30 hover:bg-secondary/60 text-foreground gap-3">
                <GoogleIcon />
                Sign up with Google
              </Button>
            </a>
            <a href={loginUrl} className="block">
              <Button variant="outline" className="w-full h-11 border-border bg-secondary/30 hover:bg-secondary/60 text-foreground gap-3">
                <AppleIcon />
                Sign up with Apple
              </Button>
            </a>
          </div>

          <div className="relative mb-6">
            <Separator className="bg-border" />
            <span className="absolute left-1/2 -translate-x-1/2 -top-2.5 bg-background px-3 text-xs text-muted-foreground">
              or sign up with email
            </span>
          </div>

          <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); window.location.href = loginUrl; }}>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor="firstName" className="text-sm text-foreground">First name</Label>
                <Input id="firstName" placeholder="Alex"
                  className="h-11 bg-secondary/30 border-border text-foreground placeholder:text-muted-foreground focus:border-primary" />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="lastName" className="text-sm text-foreground">Last name</Label>
                <Input id="lastName" placeholder="Johnson"
                  className="h-11 bg-secondary/30 border-border text-foreground placeholder:text-muted-foreground focus:border-primary" />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="email" className="text-sm text-foreground">Email address</Label>
              <Input id="email" type="email" placeholder="you@example.com"
                className="h-11 bg-secondary/30 border-border text-foreground placeholder:text-muted-foreground focus:border-primary" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="password" className="text-sm text-foreground">Password</Label>
              <Input id="password" type="password" placeholder="Min. 8 characters"
                className="h-11 bg-secondary/30 border-border text-foreground placeholder:text-muted-foreground focus:border-primary" />
            </div>
            <Button type="submit" className="w-full h-11 bg-primary text-primary-foreground hover:bg-primary/90 glow-green font-semibold">
              Create Free Account
            </Button>
            <p className="text-xs text-center text-muted-foreground">
              By signing up, you agree to our{" "}
              <a href="#" className="text-primary hover:underline">Terms of Service</a>
              {" "}and{" "}
              <a href="#" className="text-primary hover:underline">Privacy Policy</a>.
            </p>
          </form>

          <p className="text-center text-sm text-muted-foreground mt-6">
            Already have an account?{" "}
            <Link href="/login" className="text-primary hover:text-primary/80 transition-colors font-medium no-underline">
              Sign in
            </Link>
          </p>
        </motion.div>
      </div>
    </div>
  );
}

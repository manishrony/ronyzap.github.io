import { Link } from "wouter";
import { motion } from "framer-motion";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import SwingLayout from "@/components/SwingLayout";
import {
  Upload, BarChart2, TrendingUp, Crown, Zap, Activity,
  Target, Flame, Award, ChevronRight, Clock, CheckCircle2
} from "lucide-react";

const fadeUp = {
  hidden: { opacity: 0, y: 20 },
  visible: (i: number) => ({ opacity: 1, y: 0, transition: { duration: 0.4, delay: i * 0.07 } }),
};

function StatCard({ label, value, sub, color, icon: Icon, index }: {
  label: string; value: string; sub: string; color: string; icon: React.ElementType; index: number;
}) {
  return (
    <motion.div custom={index} variants={fadeUp} initial="hidden" animate="visible"
      className="bg-card border border-white/5 rounded-2xl p-5 hover:border-primary/20 transition-all duration-300">
      <div className="flex items-start justify-between mb-3">
        <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${color}`}>
          <Icon className="w-5 h-5" />
        </div>
      </div>
      <p className="font-display text-3xl font-bold text-foreground mb-0.5">{value}</p>
      <p className="text-sm font-medium text-foreground/80 mb-0.5">{label}</p>
      <p className="text-xs text-muted-foreground">{sub}</p>
    </motion.div>
  );
}

function LockedFeatureCard({ title, description }: { title: string; description: string }) {
  return (
    <div className="relative bg-card border border-white/5 rounded-2xl p-5 overflow-hidden">
      <div className="absolute inset-0 bg-background/60 backdrop-blur-[2px] z-10 flex flex-col items-center justify-center gap-3">
        <Crown className="w-6 h-6 text-primary" />
        <p className="text-sm font-semibold text-foreground">Pro Feature</p>
        <Link href="/dashboard/settings?tab=billing" className="no-underline">
          <Button size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90 text-xs h-7 px-3">
            Upgrade to Pro
          </Button>
        </Link>
      </div>
      <div className="opacity-30">
        <p className="font-semibold text-foreground mb-1">{title}</p>
        <p className="text-sm text-muted-foreground">{description}</p>
      </div>
    </div>
  );
}

export default function DashboardHome() {
  const { user } = useAuth();
  const { data: sessions, isLoading } = trpc.sessions.list.useQuery();
  const { data: analyses } = trpc.analysis.history.useQuery();

  const isPro = (user as any)?.plan === "pro" || (user as any)?.plan === "team";
  const firstName = user?.name?.split(" ")[0] ?? "Athlete";

  const recentSessions = sessions?.slice(0, 5) ?? [];
  const latestAnalysis = analyses?.[0];
  const avgBatSpeed = analyses?.length
    ? Math.round(analyses.reduce((s, a) => s + (a.batSpeedScore ?? 0), 0) / analyses.length)
    : 0;
  const streak = Math.min(analyses?.length ?? 0, 7);

  return (
    <SwingLayout>
      <div className="max-w-6xl mx-auto space-y-8">
        {/* Header */}
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }}>
          <div className="flex items-start justify-between flex-wrap gap-4">
            <div>
              <h1 className="font-display text-2xl lg:text-3xl font-bold text-foreground">
                Welcome back, {firstName} 👋
              </h1>
              <p className="text-muted-foreground mt-1">
                {sessions?.length ? `You have ${sessions.length} session${sessions.length !== 1 ? "s" : ""} recorded.` : "Upload your first swing to get started."}
              </p>
            </div>
            <Link href="/dashboard/upload" className="no-underline">
              <Button className="bg-primary text-primary-foreground hover:bg-primary/90 glow-green">
                <Upload className="w-4 h-4 mr-2" /> Upload Swing
              </Button>
            </Link>
          </div>
        </motion.div>

        {/* Stats grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard index={0} label="Avg. Bat Speed" value={avgBatSpeed ? `${avgBatSpeed}` : "—"}
            sub="out of 100" color="bg-primary/15 text-primary" icon={Zap} />
          <StatCard index={1} label="Sessions" value={String(sessions?.length ?? 0)}
            sub="total uploaded" color="bg-blue-400/15 text-blue-400" icon={Activity} />
          <StatCard index={2} label="Latest Score" value={latestAnalysis?.overallScore ? `${Math.round(latestAnalysis.overallScore)}` : "—"}
            sub="overall rating" color="bg-orange-400/15 text-orange-400" icon={Target} />
          <StatCard index={3} label="Streak" value={`${streak}d`}
            sub="consecutive days" color="bg-red-400/15 text-red-400" icon={Flame} />
        </div>

        {/* Main content grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Recent sessions */}
          <motion.div custom={4} variants={fadeUp} initial="hidden" animate="visible"
            className="lg:col-span-2 bg-card border border-white/5 rounded-2xl p-5">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-display font-semibold text-foreground">Recent Sessions</h2>
              <Link href="/dashboard/analysis" className="no-underline">
                <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-foreground text-xs">
                  View all <ChevronRight className="w-3 h-3 ml-0.5" />
                </Button>
              </Link>
            </div>

            {isLoading ? (
              <div className="space-y-3">
                {[1, 2, 3].map(i => (
                  <div key={i} className="h-14 bg-secondary/30 rounded-xl animate-pulse" />
                ))}
              </div>
            ) : recentSessions.length === 0 ? (
              <div className="text-center py-10">
                <Upload className="w-10 h-10 text-muted-foreground/40 mx-auto mb-3" />
                <p className="text-muted-foreground text-sm">No sessions yet</p>
                <p className="text-muted-foreground/60 text-xs mt-1">Upload your first swing video to begin</p>
                <Link href="/dashboard/upload" className="no-underline">
                  <Button size="sm" className="mt-4 bg-primary text-primary-foreground hover:bg-primary/90">
                    Upload Now
                  </Button>
                </Link>
              </div>
            ) : (
              <div className="space-y-2">
                {recentSessions.map((session) => (
                  <div key={session.id}
                    className="flex items-center gap-3 p-3 rounded-xl hover:bg-secondary/30 transition-colors">
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                      session.status === "completed" ? "bg-primary/15 text-primary" : "bg-muted text-muted-foreground"
                    }`}>
                      {session.status === "completed" ? <CheckCircle2 className="w-4 h-4" /> : <Clock className="w-4 h-4" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground truncate">{session.title}</p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(session.createdAt).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}
                      </p>
                    </div>
                    <Badge className={`text-xs ${session.status === "completed" ? "bg-primary/15 text-primary border-primary/20" : "bg-muted text-muted-foreground border-border"}`}>
                      {session.status}
                    </Badge>
                    <Link href={`/dashboard/analysis?session=${session.id}`} className="no-underline">
                      <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-foreground h-7 px-2">
                        <ChevronRight className="w-4 h-4" />
                      </Button>
                    </Link>
                  </div>
                ))}
              </div>
            )}
          </motion.div>

          {/* Quick actions + badges */}
          <div className="space-y-4">
            <motion.div custom={5} variants={fadeUp} initial="hidden" animate="visible"
              className="bg-card border border-white/5 rounded-2xl p-5">
              <h2 className="font-display font-semibold text-foreground mb-4">Quick Actions</h2>
              <div className="space-y-2">
                {[
                  { label: "Upload New Swing", href: "/dashboard/upload", icon: Upload, color: "text-primary" },
                  { label: "View Analysis", href: "/dashboard/analysis", icon: BarChart2, color: "text-blue-400" },
                  { label: "Track Progress", href: "/dashboard/progress", icon: TrendingUp, color: "text-orange-400" },
                ].map(({ label, href, icon: Icon, color }) => (
                  <Link key={label} href={href} className="no-underline">
                    <div className="flex items-center gap-3 p-2.5 rounded-lg hover:bg-secondary/40 transition-colors">
                      <Icon className={`w-4 h-4 ${color}`} />
                      <span className="text-sm text-foreground">{label}</span>
                      <ChevronRight className="w-3.5 h-3.5 text-muted-foreground ml-auto" />
                    </div>
                  </Link>
                ))}
              </div>
            </motion.div>

            {/* Badges */}
            <motion.div custom={6} variants={fadeUp} initial="hidden" animate="visible"
              className="bg-card border border-white/5 rounded-2xl p-5">
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-display font-semibold text-foreground">Achievements</h2>
                {!isPro && (
                  <Badge className="text-[10px] bg-primary/10 text-primary border-primary/20">Pro</Badge>
                )}
              </div>
              {isPro ? (
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { icon: "🔥", label: "On Fire", earned: streak >= 3 },
                    { icon: "⚡", label: "Speed Demon", earned: avgBatSpeed >= 80 },
                    { icon: "🎯", label: "Precision", earned: (latestAnalysis?.swingEfficiency ?? 0) >= 85 },
                    { icon: "🏆", label: "Champion", earned: (latestAnalysis?.overallScore ?? 0) >= 90 },
                    { icon: "📈", label: "Improving", earned: (sessions?.length ?? 0) >= 5 },
                    { icon: "💪", label: "Dedicated", earned: (sessions?.length ?? 0) >= 10 },
                  ].map(({ icon, label, earned }) => (
                    <div key={label} className={`flex flex-col items-center gap-1 p-2 rounded-xl border transition-all ${
                      earned ? "border-primary/30 bg-primary/10" : "border-border bg-secondary/20 opacity-40"
                    }`}>
                      <span className="text-xl">{icon}</span>
                      <span className="text-[10px] text-center text-muted-foreground leading-tight">{label}</span>
                    </div>
                  ))}
                </div>
              ) : (
                <LockedFeatureCard title="Skill Badges" description="Earn badges as you improve your swing mechanics." />
              )}
            </motion.div>
          </div>
        </div>

        {/* Pro upgrade CTA for free users */}
        {!isPro && (
          <motion.div custom={7} variants={fadeUp} initial="hidden" animate="visible"
            className="relative overflow-hidden rounded-2xl border border-primary/20 bg-primary/5 p-6">
            <div className="absolute top-0 right-0 w-64 h-64 rounded-full opacity-10"
              style={{ background: "radial-gradient(circle, oklch(0.65 0.22 145), transparent)" }} />
            <div className="relative flex flex-col sm:flex-row items-start sm:items-center gap-4 justify-between">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <Crown className="w-5 h-5 text-primary" />
                  <span className="font-display font-bold text-foreground">Upgrade to Pro</span>
                </div>
                <p className="text-sm text-muted-foreground max-w-lg">
                  Unlock unlimited analyses, hip rotation & bat lag insights, progress charts, skill badges, and more. Starting at $19/month.
                </p>
              </div>
              <Link href="/dashboard/settings?tab=billing" className="no-underline shrink-0">
                <Button className="bg-primary text-primary-foreground hover:bg-primary/90 glow-green whitespace-nowrap">
                  Upgrade to Pro <ChevronRight className="w-4 h-4 ml-1" />
                </Button>
              </Link>
            </div>
          </motion.div>
        )}
      </div>
    </SwingLayout>
  );
}

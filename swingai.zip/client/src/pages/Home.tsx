import { useRef } from "react";
import { Link } from "wouter";
import { motion, useInView } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import {
  Zap, BarChart3, Brain, ChevronRight, Star, Check, ArrowRight,
  Play, Upload, TrendingUp, Shield, Users, Award, Target, Activity
} from "lucide-react";

// ─── Animation Variants ───────────────────────────────────────────────────────
const fadeUp = {
  hidden: { opacity: 0, y: 40 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
};
const stagger = { visible: { transition: { staggerChildren: 0.1 } } };
const fadeIn = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { duration: 0.5 } },
};

function Section({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });
  return (
    <motion.div ref={ref} variants={stagger} initial="hidden" animate={inView ? "visible" : "hidden"} className={className}>
      {children}
    </motion.div>
  );
}

// ─── Navbar ───────────────────────────────────────────────────────────────────
function Navbar() {
  const { isAuthenticated } = useAuth();
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 border-b border-white/5 bg-background/80 backdrop-blur-xl">
      <div className="container flex items-center justify-between h-16">
        <Link href="/" className="flex items-center gap-2 no-underline">
          <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
            <Zap className="w-4 h-4 text-primary-foreground" />
          </div>
          <span className="font-display font-bold text-lg text-foreground">SwingAI</span>
        </Link>
        <div className="hidden md:flex items-center gap-8">
          {["Features", "How It Works", "Pricing"].map((item) => (
            <a key={item} href={`#${item.toLowerCase().replace(/ /g, "-")}`}
              className="text-sm text-muted-foreground hover:text-foreground transition-colors no-underline">
              {item}
            </a>
          ))}
        </div>
        <div className="flex items-center gap-3">
          {isAuthenticated ? (
            <Link href="/dashboard">
              <Button size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90 glow-green">
                Dashboard <ArrowRight className="w-3.5 h-3.5 ml-1" />
              </Button>
            </Link>
          ) : (
            <>
              <a href={getLoginUrl()}>
                <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-foreground">Sign In</Button>
              </a>
              <a href={getLoginUrl()}>
                <Button size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90 glow-green">
                  Get Started
                </Button>
              </a>
            </>
          )}
        </div>
      </div>
    </nav>
  );
}

// ─── Hero ─────────────────────────────────────────────────────────────────────
function Hero() {
  const { isAuthenticated } = useAuth();
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-16">
      {/* Grid background */}
      <div className="absolute inset-0 grid-bg opacity-40" />
      {/* Radial glow */}
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[600px] rounded-full"
        style={{ background: "radial-gradient(ellipse, oklch(0.65 0.22 145 / 0.12) 0%, transparent 70%)" }} />
      <div className="absolute top-1/2 left-1/4 w-[400px] h-[400px] rounded-full"
        style={{ background: "radial-gradient(ellipse, oklch(0.60 0.20 220 / 0.08) 0%, transparent 70%)" }} />

      <div className="container relative z-10 text-center">
        <motion.div variants={stagger} initial="hidden" animate="visible" className="max-w-4xl mx-auto">
          <motion.div variants={fadeUp}>
            <Badge className="mb-6 bg-primary/10 text-primary border-primary/20 px-4 py-1.5 text-sm font-medium">
              <Zap className="w-3.5 h-3.5 mr-1.5" />
              AI-Powered Baseball & Softball Training
            </Badge>
          </motion.div>

          <motion.h1 variants={fadeUp}
            className="font-display text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-bold leading-[1.05] mb-6">
            Train Smarter{" "}
            <span className="text-gradient">with AI</span>
          </motion.h1>

          <motion.p variants={fadeUp}
            className="text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto mb-10 leading-relaxed">
            Upload your swing video and receive instant AI-powered feedback on bat speed, hip rotation,
            swing efficiency, and more. Train like the pros — without the pro coaching price tag.
          </motion.p>

          <motion.div variants={fadeUp} className="flex flex-col sm:flex-row gap-4 justify-center">
            <a href={isAuthenticated ? "/dashboard" : getLoginUrl()}>
              <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90 glow-green text-base px-8 h-12 font-semibold">
                Get Started Free <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </a>
            <Button size="lg" variant="outline" className="border-border text-foreground hover:bg-secondary text-base px-8 h-12">
              <Play className="w-4 h-4 mr-2 fill-current" /> Watch Demo
            </Button>
          </motion.div>

          <motion.div variants={fadeUp} className="mt-16 flex items-center justify-center gap-8 text-sm text-muted-foreground">
            {[
              { icon: Users, label: "12,000+ Athletes" },
              { icon: Activity, label: "500K+ Swings Analyzed" },
              { icon: Award, label: "4.9/5 Rating" },
            ].map(({ icon: Icon, label }) => (
              <div key={label} className="flex items-center gap-2">
                <Icon className="w-4 h-4 text-primary" />
                <span>{label}</span>
              </div>
            ))}
          </motion.div>
        </motion.div>

        {/* Dashboard preview mockup */}
        <motion.div
          initial={{ opacity: 0, y: 80, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 0.9, delay: 0.4 }}
          className="mt-20 max-w-5xl mx-auto"
        >
          <div className="relative rounded-2xl border border-white/10 overflow-hidden shadow-2xl"
            style={{ boxShadow: "0 40px 80px oklch(0 0 0 / 0.5), 0 0 0 1px oklch(1 0 0 / 0.05)" }}>
            {/* Fake browser chrome */}
            <div className="bg-card/80 backdrop-blur px-4 py-3 border-b border-white/5 flex items-center gap-2">
              <div className="flex gap-1.5">
                <div className="w-3 h-3 rounded-full bg-red-500/70" />
                <div className="w-3 h-3 rounded-full bg-yellow-500/70" />
                <div className="w-3 h-3 rounded-full bg-green-500/70" />
              </div>
              <div className="flex-1 mx-4 bg-secondary/50 rounded-md h-6 flex items-center px-3">
                <span className="text-xs text-muted-foreground">app.swingai.com/dashboard</span>
              </div>
            </div>
            {/* Dashboard preview content */}
            <div className="bg-background/90 p-6 grid grid-cols-4 gap-4 min-h-[300px]">
              {/* Sidebar */}
              <div className="col-span-1 space-y-1">
                {["Dashboard", "Upload", "Analysis", "Progress", "Settings"].map((item, i) => (
                  <div key={item} className={`px-3 py-2 rounded-lg text-sm font-medium flex items-center gap-2 ${i === 0 ? "bg-primary/15 text-primary" : "text-muted-foreground"}`}>
                    <div className={`w-1.5 h-1.5 rounded-full ${i === 0 ? "bg-primary" : "bg-muted-foreground/30"}`} />
                    {item}
                  </div>
                ))}
              </div>
              {/* Main content */}
              <div className="col-span-3 space-y-4">
                <div className="grid grid-cols-3 gap-3">
                  {[
                    { label: "Bat Speed", value: "87", unit: "/100", color: "text-primary" },
                    { label: "Swing Efficiency", value: "79%", unit: "", color: "text-blue-400" },
                    { label: "Sessions", value: "24", unit: " total", color: "text-orange-400" },
                  ].map(({ label, value, unit, color }) => (
                    <div key={label} className="bg-card rounded-xl p-3 border border-white/5">
                      <p className="text-xs text-muted-foreground mb-1">{label}</p>
                      <p className={`text-2xl font-bold font-display ${color}`}>{value}<span className="text-xs text-muted-foreground">{unit}</span></p>
                    </div>
                  ))}
                </div>
                <div className="bg-card rounded-xl p-3 border border-white/5 h-28 flex items-end gap-1 overflow-hidden">
                  {[40, 55, 48, 62, 58, 71, 68, 75, 72, 80, 78, 87].map((h, i) => (
                    <div key={i} className="flex-1 rounded-sm"
                      style={{ height: `${h}%`, background: `oklch(0.65 0.22 145 / ${0.3 + i * 0.06})` }} />
                  ))}
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

// ─── Features ─────────────────────────────────────────────────────────────────
const features = [
  {
    icon: Brain,
    title: "AI Swing Analysis",
    description: "Frame-by-frame AI analysis measures bat speed, swing plane, hip rotation, and bat lag with professional-grade precision.",
    color: "text-primary",
    bg: "bg-primary/10",
  },
  {
    icon: BarChart3,
    title: "Progress Tracking",
    description: "Visualize your improvement over time with detailed charts showing every metric across all your training sessions.",
    color: "text-blue-400",
    bg: "bg-blue-400/10",
  },
  {
    icon: Target,
    title: "Smart Feedback",
    description: "Receive actionable drill recommendations tailored to your specific weaknesses, not generic advice.",
    color: "text-orange-400",
    bg: "bg-orange-400/10",
  },
  {
    icon: Zap,
    title: "Instant Results",
    description: "Get your full analysis report in seconds after uploading. No waiting, no scheduling — train on your schedule.",
    color: "text-yellow-400",
    bg: "bg-yellow-400/10",
  },
  {
    icon: TrendingUp,
    title: "Gamified Training",
    description: "Earn badges, maintain streaks, and level up your skill rating as you improve. Training should be motivating.",
    color: "text-purple-400",
    bg: "bg-purple-400/10",
  },
  {
    icon: Shield,
    title: "Team Management",
    description: "Coaches can manage entire rosters, compare athletes, and track team-wide progress from a single dashboard.",
    color: "text-cyan-400",
    bg: "bg-cyan-400/10",
  },
];

function Features() {
  return (
    <section id="features" className="py-32 relative">
      <div className="container">
        <Section>
          <motion.div variants={fadeUp} className="text-center mb-16">
            <Badge className="mb-4 bg-primary/10 text-primary border-primary/20">Features</Badge>
            <h2 className="font-display text-4xl md:text-5xl font-bold mb-4">
              Everything you need to{" "}
              <span className="text-gradient">elevate your game</span>
            </h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Professional-grade swing analysis tools, previously only available to elite programs, now accessible to every athlete.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((f, i) => (
              <motion.div key={f.title} variants={fadeUp}
                className="group relative bg-card border border-white/5 rounded-2xl p-6 hover:border-primary/20 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-primary/5">
                <div className={`w-12 h-12 rounded-xl ${f.bg} flex items-center justify-center mb-4`}>
                  <f.icon className={`w-6 h-6 ${f.color}`} />
                </div>
                <h3 className="font-display font-semibold text-lg mb-2 text-foreground">{f.title}</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">{f.description}</p>
                <div className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                  style={{ background: "radial-gradient(circle at 50% 0%, oklch(0.65 0.22 145 / 0.04), transparent 60%)" }} />
              </motion.div>
            ))}
          </div>
        </Section>
      </div>
    </section>
  );
}

// ─── How It Works ─────────────────────────────────────────────────────────────
const steps = [
  {
    step: "01",
    icon: Upload,
    title: "Upload Your Swing",
    description: "Record your swing on any device and upload the video directly to SwingAI. We support all common video formats.",
    color: "text-primary",
    glow: "oklch(0.65 0.22 145 / 0.3)",
  },
  {
    step: "02",
    icon: Brain,
    title: "AI Analyzes Your Mechanics",
    description: "Our AI engine processes every frame, measuring bat speed, hip rotation, swing plane, and timing with sub-millisecond precision.",
    color: "text-blue-400",
    glow: "oklch(0.60 0.20 220 / 0.3)",
  },
  {
    step: "03",
    icon: TrendingUp,
    title: "Get Your Improvement Plan",
    description: "Receive a detailed report with scores, annotated feedback, and a personalized drill plan to fix your specific weaknesses.",
    color: "text-orange-400",
    glow: "oklch(0.70 0.18 55 / 0.3)",
  },
];

function HowItWorks() {
  return (
    <section id="how-it-works" className="py-32 relative">
      <div className="absolute inset-0"
        style={{ background: "radial-gradient(ellipse at 50% 50%, oklch(0.65 0.22 145 / 0.04) 0%, transparent 70%)" }} />
      <div className="container relative">
        <Section>
          <motion.div variants={fadeUp} className="text-center mb-16">
            <Badge className="mb-4 bg-primary/10 text-primary border-primary/20">How It Works</Badge>
            <h2 className="font-display text-4xl md:text-5xl font-bold mb-4">
              From upload to insight{" "}
              <span className="text-gradient">in seconds</span>
            </h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Three simple steps stand between you and professional-level swing analysis.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative">
            {/* Connector line */}
            <div className="hidden md:block absolute top-16 left-[calc(16.67%+2rem)] right-[calc(16.67%+2rem)] h-px"
              style={{ background: "linear-gradient(90deg, oklch(0.65 0.22 145 / 0.5), oklch(0.60 0.20 220 / 0.5), oklch(0.70 0.18 55 / 0.5))" }} />

            {steps.map((s, i) => (
              <motion.div key={s.step} variants={fadeUp} className="relative text-center">
                <div className="relative inline-flex items-center justify-center w-16 h-16 rounded-2xl mb-6 mx-auto"
                  style={{ background: `oklch(0.13 0.015 260)`, boxShadow: `0 0 30px ${s.glow}`, border: "1px solid oklch(1 0 0 / 0.1)" }}>
                  <s.icon className={`w-7 h-7 ${s.color}`} />
                  <div className="absolute -top-3 -right-3 w-7 h-7 rounded-full bg-background border border-border flex items-center justify-center">
                    <span className="text-xs font-bold font-display text-muted-foreground">{s.step}</span>
                  </div>
                </div>
                <h3 className="font-display font-semibold text-xl mb-3 text-foreground">{s.title}</h3>
                <p className="text-muted-foreground text-sm leading-relaxed max-w-xs mx-auto">{s.description}</p>
              </motion.div>
            ))}
          </div>
        </Section>
      </div>
    </section>
  );
}

// ─── Testimonials ─────────────────────────────────────────────────────────────
const testimonials = [
  {
    name: "Marcus Rivera",
    role: "High School Varsity Outfielder",
    avatar: "MR",
    rating: 5,
    text: "SwingAI completely changed how I train. I went from a .280 average to .340 in one season after following the hip rotation drills it recommended. The feedback is incredibly specific.",
  },
  {
    name: "Coach Dana Whitfield",
    role: "College Softball Head Coach",
    avatar: "DW",
    rating: 5,
    text: "I use SwingAI Team for my entire roster. The ability to compare swing mechanics across 18 players and track progress over the season is something I couldn't do before without expensive equipment.",
  },
  {
    name: "Tyler Okonkwo",
    role: "Independent Baseball Trainer",
    avatar: "TO",
    rating: 5,
    text: "My clients see results faster because the AI catches things I might miss in real-time. The bat lag analysis alone has helped three of my students add 8+ mph to their exit velocity.",
  },
  {
    name: "Sofia Hernandez",
    role: "Travel Softball Player, 16U",
    avatar: "SH",
    rating: 5,
    text: "I love the streak system — it keeps me motivated to upload sessions every week. My bat speed went from 58 to 71 mph in four months. The progress charts make it so satisfying to see.",
  },
  {
    name: "James Calloway",
    role: "Amateur Baseball League Player",
    avatar: "JC",
    rating: 5,
    text: "I'm 34 and still playing competitive amateur ball. SwingAI helped me identify that my weight transfer was off, which explained why I was losing power. Fixed it in two weeks of targeted drills.",
  },
  {
    name: "Priya Nair",
    role: "Youth Softball Coach",
    avatar: "PN",
    rating: 5,
    text: "Parents love seeing the data. When I show them their kid's bat speed progression chart, it builds trust and keeps them engaged in the program. SwingAI is a game-changer for youth coaching.",
  },
];

function Testimonials() {
  return (
    <section id="testimonials" className="py-32 overflow-hidden">
      <div className="container">
        <Section>
          <motion.div variants={fadeUp} className="text-center mb-16">
            <Badge className="mb-4 bg-primary/10 text-primary border-primary/20">Testimonials</Badge>
            <h2 className="font-display text-4xl md:text-5xl font-bold mb-4">
              Trusted by athletes{" "}
              <span className="text-gradient">at every level</span>
            </h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              From high school players to college coaches — SwingAI delivers results.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {testimonials.map((t, i) => (
              <motion.div key={t.name} variants={fadeUp}
                className="bg-card border border-white/5 rounded-2xl p-6 hover:border-primary/20 transition-all duration-300">
                <div className="flex items-center gap-1 mb-4">
                  {Array.from({ length: t.rating }).map((_, j) => (
                    <Star key={j} className="w-4 h-4 fill-primary text-primary" />
                  ))}
                </div>
                <p className="text-foreground/90 text-sm leading-relaxed mb-6">"{t.text}"</p>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center text-primary font-bold text-sm font-display">
                    {t.avatar}
                  </div>
                  <div>
                    <p className="font-semibold text-sm text-foreground">{t.name}</p>
                    <p className="text-xs text-muted-foreground">{t.role}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </Section>
      </div>
    </section>
  );
}

// ─── Pricing ──────────────────────────────────────────────────────────────────
const plans = [
  {
    name: "Free",
    price: "$0",
    period: "/month",
    description: "Perfect for getting started and exploring the platform.",
    features: [
      "3 swing analyses per month",
      "Basic bat speed score",
      "Swing efficiency rating",
      "7-day session history",
      "Community access",
    ],
    locked: ["Advanced body positioning notes", "Hip rotation analysis", "Bat lag timing", "Progress charts", "Gamification & badges"],
    cta: "Get Started Free",
    highlight: false,
    badge: null,
  },
  {
    name: "Pro",
    price: "$19",
    period: "/month",
    description: "For serious athletes who want the full analysis experience.",
    features: [
      "Unlimited swing analyses",
      "Full AI feedback suite",
      "Hip rotation & bat lag analysis",
      "Body positioning notes",
      "Progress charts & trends",
      "Gamification & skill badges",
      "Streak tracking",
      "Priority support",
    ],
    locked: [],
    cta: "Start Pro Trial",
    highlight: true,
    badge: "Most Popular",
  },
  {
    name: "Team",
    price: "$79",
    period: "/month",
    description: "For coaches managing multiple athletes and rosters.",
    features: [
      "Everything in Pro",
      "Up to 20 athlete profiles",
      "Team dashboard & roster view",
      "Comparative analysis",
      "Bulk video uploads",
      "Coach annotations",
      "CSV data export",
      "Dedicated account manager",
    ],
    locked: [],
    cta: "Start Team Trial",
    highlight: false,
    badge: "For Coaches",
  },
];

function Pricing() {
  const { isAuthenticated } = useAuth();
  return (
    <section id="pricing" className="py-32 relative">
      <div className="absolute inset-0"
        style={{ background: "radial-gradient(ellipse at 50% 100%, oklch(0.65 0.22 145 / 0.05) 0%, transparent 60%)" }} />
      <div className="container relative">
        <Section>
          <motion.div variants={fadeUp} className="text-center mb-16">
            <Badge className="mb-4 bg-primary/10 text-primary border-primary/20">Pricing</Badge>
            <h2 className="font-display text-4xl md:text-5xl font-bold mb-4">
              Simple, transparent{" "}
              <span className="text-gradient">pricing</span>
            </h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Start free, upgrade when you're ready. No hidden fees, no long-term contracts.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
            {plans.map((plan) => (
              <motion.div key={plan.name} variants={fadeUp}
                className={`relative rounded-2xl p-6 border transition-all duration-300 ${
                  plan.highlight
                    ? "border-primary/40 bg-primary/5 shadow-xl shadow-primary/10 scale-[1.02]"
                    : "border-white/5 bg-card hover:border-white/10"
                }`}>
                {plan.badge && (
                  <div className="absolute -top-3.5 left-1/2 -translate-x-1/2">
                    <Badge className={`px-3 py-1 text-xs font-semibold ${plan.highlight ? "bg-primary text-primary-foreground" : "bg-secondary text-secondary-foreground"}`}>
                      {plan.badge}
                    </Badge>
                  </div>
                )}

                <div className="mb-6">
                  <h3 className="font-display font-bold text-xl mb-1 text-foreground">{plan.name}</h3>
                  <div className="flex items-baseline gap-1 mb-2">
                    <span className="font-display text-4xl font-bold text-foreground">{plan.price}</span>
                    <span className="text-muted-foreground text-sm">{plan.period}</span>
                  </div>
                  <p className="text-muted-foreground text-sm">{plan.description}</p>
                </div>

                <a href={isAuthenticated ? "/dashboard" : getLoginUrl()}>
                  <Button className={`w-full mb-6 ${plan.highlight ? "bg-primary text-primary-foreground hover:bg-primary/90 glow-green" : "bg-secondary text-secondary-foreground hover:bg-secondary/80"}`}>
                    {plan.cta} <ChevronRight className="w-4 h-4 ml-1" />
                  </Button>
                </a>

                <div className="space-y-2.5">
                  {plan.features.map((f) => (
                    <div key={f} className="flex items-start gap-2.5">
                      <Check className="w-4 h-4 text-primary mt-0.5 shrink-0" />
                      <span className="text-sm text-foreground/80">{f}</span>
                    </div>
                  ))}
                  {plan.locked.map((f) => (
                    <div key={f} className="flex items-start gap-2.5 opacity-40">
                      <div className="w-4 h-4 mt-0.5 shrink-0 flex items-center justify-center">
                        <div className="w-3 h-px bg-muted-foreground" />
                      </div>
                      <span className="text-sm text-muted-foreground line-through">{f}</span>
                    </div>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
        </Section>
      </div>
    </section>
  );
}

// ─── Footer ───────────────────────────────────────────────────────────────────
function Footer() {
  return (
    <footer className="border-t border-white/5 py-12">
      <div className="container">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-primary flex items-center justify-center">
              <Zap className="w-3.5 h-3.5 text-primary-foreground" />
            </div>
            <span className="font-display font-bold text-foreground">SwingAI</span>
          </div>
          <p className="text-sm text-muted-foreground text-center">
            © 2026 Ronyzap LLC. All rights reserved.
          </p>
          <div className="flex gap-6 text-sm text-muted-foreground">
            <a href="#" className="hover:text-foreground transition-colors no-underline">Privacy</a>
            <a href="#" className="hover:text-foreground transition-colors no-underline">Terms</a>
            <a href="#" className="hover:text-foreground transition-colors no-underline">Contact</a>
          </div>
        </div>
      </div>
    </footer>
  );
}

// ─── Main Export ──────────────────────────────────────────────────────────────
export default function Home() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navbar />
      <Hero />
      <Features />
      <HowItWorks />
      <Testimonials />
      <Pricing />
      <Footer />
    </div>
  );
}

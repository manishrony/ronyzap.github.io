import { useState, useRef, useCallback } from "react";
import { useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import SwingLayout from "@/components/SwingLayout";
import { toast } from "sonner";
import {
  Upload, Video, X, CheckCircle2, Loader2, CloudUpload,
  FileVideo, AlertCircle, ArrowRight
} from "lucide-react";
import { Link } from "wouter";

type UploadState = "idle" | "selected" | "uploading" | "processing" | "done" | "error";

export default function UploadPage() {
  const [, navigate] = useLocation();
  const [state, setState] = useState<UploadState>("idle");
  const [file, setFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [title, setTitle] = useState("");
  const [isDragging, setIsDragging] = useState(false);
  const [sessionId, setSessionId] = useState<number | null>(null);
  const [progress, setProgress] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const createSession = trpc.sessions.create.useMutation();
  const uploadVideo = trpc.sessions.uploadVideo.useMutation();
  const analyzeSession = trpc.sessions.analyze.useMutation();

  const handleFile = useCallback((f: File) => {
    if (!f.type.startsWith("video/")) {
      toast.error("Please upload a video file (MP4, MOV, AVI, etc.)");
      return;
    }
    if (f.size > 100 * 1024 * 1024) {
      toast.error("File too large. Maximum size is 100MB.");
      return;
    }
    setFile(f);
    setPreviewUrl(URL.createObjectURL(f));
    setTitle(f.name.replace(/\.[^/.]+$/, "").replace(/[-_]/g, " "));
    setState("selected");
  }, []);

  const onDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const f = e.dataTransfer.files[0];
    if (f) handleFile(f);
  }, [handleFile]);

  const onDragOver = (e: React.DragEvent) => { e.preventDefault(); setIsDragging(true); };
  const onDragLeave = () => setIsDragging(false);

  const handleSubmit = async () => {
    if (!file) return;
    setState("uploading");
    setProgress(0);

    try {
      // 1. Create session
      const session = await createSession.mutateAsync({ title: title || "Swing Session" });
      if (!session) throw new Error("Failed to create session");
      setSessionId(session.id);
      setProgress(25);

      // 2. Convert to base64 and upload
      const reader = new FileReader();
      reader.onload = async (e) => {
        const base64 = (e.target?.result as string).split(",")[1];
        setProgress(50);
        try {
          await uploadVideo.mutateAsync({
            sessionId: session.id,
            fileName: file.name,
            fileData: base64,
            mimeType: file.type,
          });
          setProgress(75);
          setState("processing");

          // 3. Run AI analysis
          await analyzeSession.mutateAsync({ sessionId: session.id });
          setProgress(100);
          setState("done");
          toast.success("Analysis complete! Your swing has been analyzed.");
        } catch (err) {
          setState("error");
          toast.error("Upload failed. Please try again.");
        }
      };
      reader.readAsDataURL(file);
    } catch (err) {
      setState("error");
      toast.error("Failed to create session. Please try again.");
    }
  };

  const reset = () => {
    setState("idle");
    setFile(null);
    setPreviewUrl(null);
    setTitle("");
    setProgress(0);
    setSessionId(null);
  };

  return (
    <SwingLayout>
      <div className="max-w-2xl mx-auto space-y-6">
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
          <h1 className="font-display text-2xl lg:text-3xl font-bold text-foreground mb-1">Upload Swing</h1>
          <p className="text-muted-foreground">Upload a video of your swing and our AI will analyze your mechanics instantly.</p>
        </motion.div>

        <AnimatePresence mode="wait">
          {/* Done state */}
          {state === "done" && (
            <motion.div key="done" initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}
              className="bg-card border border-primary/20 rounded-2xl p-8 text-center">
              <div className="w-16 h-16 rounded-full bg-primary/15 flex items-center justify-center mx-auto mb-4">
                <CheckCircle2 className="w-8 h-8 text-primary" />
              </div>
              <h2 className="font-display text-xl font-bold text-foreground mb-2">Analysis Complete!</h2>
              <p className="text-muted-foreground mb-6">Your swing has been analyzed. View your full AI feedback report now.</p>
              <div className="flex gap-3 justify-center">
                {sessionId && (
                  <Link href={`/dashboard/analysis?session=${sessionId}`} className="no-underline">
                    <Button className="bg-primary text-primary-foreground hover:bg-primary/90 glow-green">
                      View Analysis <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  </Link>
                )}
                <Button variant="outline" onClick={reset} className="border-border text-foreground hover:bg-secondary">
                  Upload Another
                </Button>
              </div>
            </motion.div>
          )}

          {/* Uploading/Processing state */}
          {(state === "uploading" || state === "processing") && (
            <motion.div key="uploading" initial={{ opacity: 0 }} animate={{ opacity: 1 }}
              className="bg-card border border-white/5 rounded-2xl p-8 text-center">
              <div className="w-16 h-16 rounded-full bg-primary/15 flex items-center justify-center mx-auto mb-4">
                {state === "processing" ? (
                  <Loader2 className="w-8 h-8 text-primary animate-spin" />
                ) : (
                  <CloudUpload className="w-8 h-8 text-primary" />
                )}
              </div>
              <h2 className="font-display text-xl font-bold text-foreground mb-2">
                {state === "uploading" ? "Uploading your swing..." : "AI is analyzing your mechanics..."}
              </h2>
              <p className="text-muted-foreground mb-6 text-sm">
                {state === "uploading" ? "Please wait while your video uploads." : "Measuring bat speed, hip rotation, swing efficiency, and more."}
              </p>
              <div className="w-full bg-secondary rounded-full h-2 mb-2">
                <motion.div className="bg-primary h-2 rounded-full" animate={{ width: `${progress}%` }} transition={{ duration: 0.5 }} />
              </div>
              <p className="text-xs text-muted-foreground">{progress}% complete</p>
            </motion.div>
          )}

          {/* Error state */}
          {state === "error" && (
            <motion.div key="error" initial={{ opacity: 0 }} animate={{ opacity: 1 }}
              className="bg-card border border-destructive/30 rounded-2xl p-8 text-center">
              <AlertCircle className="w-12 h-12 text-destructive mx-auto mb-4" />
              <h2 className="font-display text-xl font-bold text-foreground mb-2">Upload Failed</h2>
              <p className="text-muted-foreground mb-6">Something went wrong. Please try again.</p>
              <Button onClick={reset} className="bg-primary text-primary-foreground hover:bg-primary/90">Try Again</Button>
            </motion.div>
          )}

          {/* Idle / Selected state */}
          {(state === "idle" || state === "selected") && (
            <motion.div key="upload" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
              {/* Drop zone */}
              <div
                onDrop={onDrop} onDragOver={onDragOver} onDragLeave={onDragLeave}
                onClick={() => state === "idle" && fileInputRef.current?.click()}
                className={`relative border-2 border-dashed rounded-2xl transition-all duration-200 ${
                  isDragging
                    ? "border-primary bg-primary/10 scale-[1.01]"
                    : state === "selected"
                    ? "border-primary/40 bg-primary/5"
                    : "border-border hover:border-primary/40 hover:bg-secondary/20 cursor-pointer"
                }`}>

                {state === "selected" && previewUrl ? (
                  <div className="relative">
                    <video src={previewUrl} className="w-full rounded-2xl max-h-72 object-cover" controls />
                    <button onClick={(e) => { e.stopPropagation(); reset(); }}
                      className="absolute top-3 right-3 w-8 h-8 rounded-full bg-background/80 backdrop-blur flex items-center justify-center hover:bg-background transition-colors">
                      <X className="w-4 h-4 text-foreground" />
                    </button>
                    <div className="absolute bottom-3 left-3 bg-background/80 backdrop-blur rounded-lg px-3 py-1.5 flex items-center gap-2">
                      <FileVideo className="w-3.5 h-3.5 text-primary" />
                      <span className="text-xs text-foreground font-medium">{file?.name}</span>
                      <span className="text-xs text-muted-foreground">({(file!.size / 1024 / 1024).toFixed(1)} MB)</span>
                    </div>
                  </div>
                ) : (
                  <div className="py-16 px-8 text-center">
                    <div className={`w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4 transition-colors ${
                      isDragging ? "bg-primary/20" : "bg-secondary/50"
                    }`}>
                      <Upload className={`w-8 h-8 transition-colors ${isDragging ? "text-primary" : "text-muted-foreground"}`} />
                    </div>
                    <p className="font-display font-semibold text-foreground mb-1">
                      {isDragging ? "Drop it here!" : "Drag & drop your swing video"}
                    </p>
                    <p className="text-sm text-muted-foreground mb-4">or click to browse files</p>
                    <div className="flex items-center justify-center gap-3 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1"><Video className="w-3 h-3" /> MP4, MOV, AVI</span>
                      <span>•</span>
                      <span>Max 100MB</span>
                    </div>
                  </div>
                )}
              </div>

              <input ref={fileInputRef} type="file" accept="video/*" className="hidden"
                onChange={(e) => { const f = e.target.files?.[0]; if (f) handleFile(f); }} />

              {/* Title input */}
              {state === "selected" && (
                <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-1.5">
                  <Label className="text-sm text-foreground">Session Title</Label>
                  <Input value={title} onChange={(e) => setTitle(e.target.value)}
                    placeholder="e.g. Tuesday batting practice"
                    className="h-11 bg-secondary/30 border-border text-foreground placeholder:text-muted-foreground focus:border-primary" />
                </motion.div>
              )}

              {/* Submit */}
              {state === "selected" && (
                <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
                  <Button onClick={handleSubmit} className="w-full h-12 bg-primary text-primary-foreground hover:bg-primary/90 glow-green font-semibold text-base">
                    <Loader2 className="w-4 h-4 mr-2 hidden" />
                    Analyze My Swing <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </motion.div>
              )}

              {/* Tips */}
              <div className="bg-card border border-white/5 rounded-xl p-4">
                <p className="text-sm font-semibold text-foreground mb-3">Tips for best results</p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {[
                    "Film from the side (perpendicular to the swing plane)",
                    "Ensure good lighting — avoid backlighting",
                    "Keep the full body in frame from head to feet",
                    "Record at 60fps or higher for accurate timing",
                  ].map((tip) => (
                    <div key={tip} className="flex items-start gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-primary mt-0.5 shrink-0" />
                      <span className="text-xs text-muted-foreground">{tip}</span>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </SwingLayout>
  );
}

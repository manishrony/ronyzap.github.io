import { useState } from "react";
import { motion } from "framer-motion";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import SwingLayout from "@/components/SwingLayout";
import {
  LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, RadarChart, Radar, PolarGrid,
  PolarAngleAxis, PolarRadiusAxis
} from "recharts";
import {
  Crown, TrendingUp, Flame, Award, ChevronRight, Upload,
  Zap, Target, RotateCcw, Clock, CheckCircle2, Star
} from "lucide-react";

const fadeUp = {
  hidden: { opacity: 0, y: 20 },
  visible: (i: number) => ({ opacity: 1, y: 0, transition: { duration: 0.4, delay: i * 0.08 } }),
};

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-card border border-border rounded-xl p-3 shadow-xl text-sm">
      <p className="text-muted-foreground text-xs mb-1">{label}</p>
      {payload.map((p: any) => (
        <p key={p.name} className="font-medium" style={{ color: p.color }}>
          {p.name}: <span className="text-foreground">{Math.round(p.value)}</span>
        </p>
      ))}
    </div>
  );
};

function LockedChart({ title, description }: { title: string; description: string }) {
  return (
    <div className="relative bg-card border border-white/5 rounded-2xl p-5 overflow-hidden">
      <div className="absolute inset-0 bg-background/70 backdrop-blur-[2px] z-10 flex flex-col items-center justify-center gap-3">
        <Crown className="w-8 h-8 text-primary" />
        <p className="font-display font-semibold text-foreground">Pro Feature</p>
        <p className="text-sm text-muted-foreground text-center max-w-xs">{description}</p>
        <Link href="/dashboard/settings?tab=billing" className="no-underline">
          <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
            Upgrade to Pro <ChevronRight className="w-4 h-4 ml-1" />
          </Button>
        </Link>
      </div>
      <div className="opacity-10">
        <h3 className="font-display font-semibold text-foreground mb-4">{title}</h3>
        <div className="h-48 bg-secondary/30 rounded-xl" />
      </div>
    </div>
  );
}

const badges = [
  { id: "first_swing", icon: "⚡", label: "First Swing", description: "Uploaded your first session", threshold: 1, field: "sessions" },
  { id: "five_sessions", icon: "🎯", label: "Dedicated", description: "Completed 5 sessions", threshold: 5, field: "sessions" },
  { id: "ten_sessions", icon: "💪", label: "Committed", description: "Completed 10 sessions", threshold: 10, field: "sessions" },
  { id: "speed_70", icon: "🔥", label: "Speed Demon", description: "Bat speed score 70+", threshold: 70, field: "batSpeed" },
  { id: "speed_85", icon: "⚡", label: "Power Hitter", description: "Bat speed score 85+", threshold: 85, field: "batSpeed" },
  { id: "efficiency_80", icon: "🎯", label: "Precision", description: "Swing efficiency 80+", threshold: 80, field: "efficiency" },
  { id: "overall_85", icon: "🏆", label: "Elite", description: "Overall score 85+", threshold: 85, field: "overall" },
  { id: "streak_3", icon: "🌟", label: "On Fire", description: "3-day training streak", threshold: 3, field: "streak" },
];

export default function ProgressPage() {
  const { user } = useAuth();
  const isPro = (user as any)?.plan === "pro" || (user as any)?.plan === "team";

  const { data: analyses, isLoading } = trpc.analysis.history.useQuery();
  const { data: sessions } = trpc.sessions.list.useQuery();

  // Build chart data from analyses (most recent last)
  const chartData = [...(analyses ?? [])].reverse().map((a, i) => ({
    session: `S${i + 1}`,
    "Bat Speed": Math.round(a.batSpeedScore ?? 0),
    "Swing Efficiency": Math.round(a.swingEfficiency ?? 0),
    "Hip Rotation": Math.round(a.hipRotation ?? 0),
    "Bat Lag": Math.round(a.batLagScore ?? 0),
    "Overall": Math.round(a.overallScore ?? 0),
  }));

  const latestAnalysis = analyses?.[0];
  const radarData = latestAnalysis ? [
    { metric: "Bat Speed", value: Math.round(latestAnalysis.batSpeedScore ?? 0) },
    { metric: "Efficiency", value: Math.round(latestAnalysis.swingEfficiency ?? 0) },
    { metric: "Hip Rotation", value: Math.round(latestAnalysis.hipRotation ?? 0) },
    { metric: "Bat Lag", value: Math.round(latestAnalysis.batLagScore ?? 0) },
    { metric: "Overall", value: Math.round(latestAnalysis.overallScore ?? 0) },
  ] : [];

  const streak = Math.min(sessions?.length ?? 0, 7);
  const avgBatSpeed = analyses?.length
    ? Math.round(analyses.reduce((s, a) => s + (a.batSpeedScore ?? 0), 0) / analyses.length)
    : 0;
  const avgEfficiency = analyses?.length
    ? Math.round(analyses.reduce((s, a) => s + (a.swingEfficiency ?? 0), 0) / analyses.length)
    : 0;

  // Determine earned badges
  const earnedBadgeIds = new Set(
    badges.filter(b => {
      if (b.field === "sessions") return (sessions?.length ?? 0) >= b.threshold;
      if (b.field === "batSpeed") return avgBatSpeed >= b.threshold;
      if (b.field === "efficiency") return avgEfficiency >= b.threshold;
      if (b.field === "overall") return Math.round(latestAnalysis?.overallScore ?? 0) >= b.threshold;
      if (b.field === "streak") return streak >= b.threshold;
      return false;
    }).map(b => b.id)
  );

  return (
    <SwingLayout>
      <div className="max-w-5xl mx-auto space-y-6">
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
          <h1 className="font-display text-2xl lg:text-3xl font-bold text-foreground mb-1">Progress</h1>
          <p className="text-muted-foreground">Track your improvement over time and celebrate your milestones.</p>
        </motion.div>

        {/* Summary stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { label: "Sessions", value: String(sessions?.length ?? 0), icon: Target, color: "text-primary bg-primary/15" },
            { label: "Avg Bat Speed", value: avgBatSpeed ? String(avgBatSpeed) : "—", icon: Zap, color: "text-blue-400 bg-blue-400/15" },
            { label: "Avg Efficiency", value: avgEfficiency ? `${avgEfficiency}%` : "—", icon: TrendingUp, color: "text-orange-400 bg-orange-400/15" },
            { label: "Streak", value: `${streak}d`, icon: Flame, color: "text-red-400 bg-red-400/15" },
          ].map(({ label, value, icon: Icon, color }, i) => (
            <motion.div key={label} custom={i} variants={fadeUp} initial="hidden" animate="visible"
              className="bg-card border border-white/5 rounded-2xl p-4">
              <div className={`w-9 h-9 rounded-xl flex items-center justify-center mb-3 ${color}`}>
                <Icon className="w-4.5 h-4.5" />
              </div>
              <p className="font-display text-2xl font-bold text-foreground">{value}</p>
              <p className="text-xs text-muted-foreground mt-0.5">{label}</p>
            </motion.div>
          ))}
        </div>

        {/* No data */}
        {!analyses?.length && !isLoading && (
          <div className="text-center py-16 bg-card border border-white/5 rounded-2xl">
            <TrendingUp className="w-12 h-12 text-muted-foreground/40 mx-auto mb-4" />
            <p className="font-display font-semibold text-foreground mb-2">No data yet</p>
            <p className="text-muted-foreground text-sm mb-6">Upload and analyze swings to see your progress charts.</p>
            <Link href="/dashboard/upload" className="no-underline">
              <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
                <Upload className="w-4 h-4 mr-2" /> Upload First Swing
              </Button>
            </Link>
          </div>
        )}

        {analyses && analyses.length > 0 && (
          <>
            {/* Overall progress chart */}
            {isPro ? (
              <motion.div custom={4} variants={fadeUp} initial="hidden" animate="visible"
                className="bg-card border border-white/5 rounded-2xl p-5">
                <h2 className="font-display font-semibold text-foreground mb-4">Performance Over Time</h2>
                <ResponsiveContainer width="100%" height={260}>
                  <AreaChart data={chartData}>
                    <defs>
                      <linearGradient id="batSpeedGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="oklch(0.65 0.22 145)" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="oklch(0.65 0.22 145)" stopOpacity={0} />
                      </linearGradient>
                      <linearGradient id="overallGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="oklch(0.60 0.20 200)" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="oklch(0.60 0.20 200)" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.22 0.015 260)" />
                    <XAxis dataKey="session" tick={{ fill: "oklch(0.55 0.01 260)", fontSize: 12 }} axisLine={false} tickLine={false} />
                    <YAxis domain={[0, 100]} tick={{ fill: "oklch(0.55 0.01 260)", fontSize: 12 }} axisLine={false} tickLine={false} />
                    <Tooltip content={<CustomTooltip />} />
                    <Area type="monotone" dataKey="Bat Speed" stroke="oklch(0.65 0.22 145)" strokeWidth={2} fill="url(#batSpeedGrad)" />
                    <Area type="monotone" dataKey="Overall" stroke="oklch(0.60 0.20 200)" strokeWidth={2} fill="url(#overallGrad)" />
                  </AreaChart>
                </ResponsiveContainer>
              </motion.div>
            ) : (
              <LockedChart title="Performance Over Time" description="Track your bat speed, swing efficiency, and overall score across all sessions." />
            )}

            {/* Multi-metric chart + radar */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {isPro ? (
                <>
                  <motion.div custom={5} variants={fadeUp} initial="hidden" animate="visible"
                    className="bg-card border border-white/5 rounded-2xl p-5">
                    <h2 className="font-display font-semibold text-foreground mb-4">Metrics Breakdown</h2>
                    <ResponsiveContainer width="100%" height={220}>
                      <LineChart data={chartData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.22 0.015 260)" />
                        <XAxis dataKey="session" tick={{ fill: "oklch(0.55 0.01 260)", fontSize: 11 }} axisLine={false} tickLine={false} />
                        <YAxis domain={[0, 100]} tick={{ fill: "oklch(0.55 0.01 260)", fontSize: 11 }} axisLine={false} tickLine={false} />
                        <Tooltip content={<CustomTooltip />} />
                        <Line type="monotone" dataKey="Bat Speed" stroke="oklch(0.65 0.22 145)" strokeWidth={2} dot={{ r: 3, fill: "oklch(0.65 0.22 145)" }} />
                        <Line type="monotone" dataKey="Swing Efficiency" stroke="oklch(0.60 0.20 200)" strokeWidth={2} dot={{ r: 3, fill: "oklch(0.60 0.20 200)" }} />
                        <Line type="monotone" dataKey="Hip Rotation" stroke="oklch(0.70 0.18 55)" strokeWidth={2} dot={{ r: 3, fill: "oklch(0.70 0.18 55)" }} />
                      </LineChart>
                    </ResponsiveContainer>
                  </motion.div>

                  <motion.div custom={6} variants={fadeUp} initial="hidden" animate="visible"
                    className="bg-card border border-white/5 rounded-2xl p-5">
                    <h2 className="font-display font-semibold text-foreground mb-4">Latest Session Radar</h2>
                    <ResponsiveContainer width="100%" height={220}>
                      <RadarChart data={radarData}>
                        <PolarGrid stroke="oklch(0.22 0.015 260)" />
                        <PolarAngleAxis dataKey="metric" tick={{ fill: "oklch(0.55 0.01 260)", fontSize: 11 }} />
                        <PolarRadiusAxis angle={30} domain={[0, 100]} tick={{ fill: "oklch(0.55 0.01 260)", fontSize: 10 }} />
                        <Radar name="Score" dataKey="value" stroke="oklch(0.65 0.22 145)" fill="oklch(0.65 0.22 145)" fillOpacity={0.2} />
                      </RadarChart>
                    </ResponsiveContainer>
                  </motion.div>
                </>
              ) : (
                <>
                  <LockedChart title="Metrics Breakdown" description="Compare bat speed, efficiency, and hip rotation across sessions." />
                  <LockedChart title="Skill Radar" description="See your strengths and weaknesses at a glance with the radar chart." />
                </>
              )}
            </div>

            {/* Session history */}
            <motion.div custom={7} variants={fadeUp} initial="hidden" animate="visible"
              className="bg-card border border-white/5 rounded-2xl p-5">
              <h2 className="font-display font-semibold text-foreground mb-4">Session History</h2>
              <div className="space-y-2">
                {sessions?.map((session, i) => {
                  const analysis = analyses?.find(a => a.sessionId === session.id);
                  return (
                    <div key={session.id}
                      className="flex items-center gap-3 p-3 rounded-xl hover:bg-secondary/30 transition-colors">
                      <div className="w-8 h-8 rounded-lg bg-primary/15 flex items-center justify-center shrink-0">
                        <span className="text-xs font-bold text-primary">#{sessions.length - i}</span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-foreground truncate">{session.title}</p>
                        <p className="text-xs text-muted-foreground">
                          {new Date(session.createdAt).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}
                        </p>
                      </div>
                      {analysis && (
                        <div className="hidden sm:flex items-center gap-3 text-xs text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <Zap className="w-3 h-3 text-primary" />
                            {Math.round(analysis.batSpeedScore ?? 0)}
                          </span>
                          <span className="flex items-center gap-1">
                            <Target className="w-3 h-3 text-blue-400" />
                            {Math.round(analysis.overallScore ?? 0)}
                          </span>
                        </div>
                      )}
                      <Link href={`/dashboard/analysis?session=${session.id}`} className="no-underline">
                        <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-foreground h-7 px-2 text-xs">
                          View
                        </Button>
                      </Link>
                    </div>
                  );
                })}
              </div>
            </motion.div>
          </>
        )}

        {/* Badges */}
        <motion.div custom={8} variants={fadeUp} initial="hidden" animate="visible"
          className="bg-card border border-white/5 rounded-2xl p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-display font-semibold text-foreground">Achievements</h2>
            <span className="text-sm text-muted-foreground">{earnedBadgeIds.size}/{badges.length} earned</span>
          </div>

          {isPro ? (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {badges.map((badge) => {
                const earned = earnedBadgeIds.has(badge.id);
                return (
                  <div key={badge.id}
                    className={`flex flex-col items-center gap-2 p-4 rounded-xl border transition-all ${
                      earned
                        ? "border-primary/30 bg-primary/10"
                        : "border-border bg-secondary/20 opacity-40 grayscale"
                    }`}>
                    <span className="text-3xl">{badge.icon}</span>
                    <p className="text-sm font-semibold text-foreground text-center">{badge.label}</p>
                    <p className="text-xs text-muted-foreground text-center leading-tight">{badge.description}</p>
                    {earned && <Badge className="text-[10px] bg-primary/20 text-primary border-primary/30 px-2">Earned</Badge>}
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="relative">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 opacity-20 pointer-events-none">
                {badges.slice(0, 4).map((badge) => (
                  <div key={badge.id} className="flex flex-col items-center gap-2 p-4 rounded-xl border border-border bg-secondary/20">
                    <span className="text-3xl">{badge.icon}</span>
                    <p className="text-sm font-semibold text-foreground text-center">{badge.label}</p>
                  </div>
                ))}
              </div>
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-3">
                <Crown className="w-8 h-8 text-primary" />
                <p className="font-display font-semibold text-foreground">Unlock Achievements</p>
                <p className="text-sm text-muted-foreground text-center max-w-xs">Earn badges and track your milestones with a Pro subscription.</p>
                <Link href="/dashboard/settings?tab=billing" className="no-underline">
                  <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
                    Upgrade to Pro <ChevronRight className="w-4 h-4 ml-1" />
                  </Button>
                </Link>
              </div>
            </div>
          )}
        </motion.div>
      </div>
    </SwingLayout>
  );
}

import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import SwingLayout from "@/components/SwingLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Users, Mail, Check, X, Loader2 } from "lucide-react";
import { toast } from "sonner";

export default function TeamPage() {
  const { user } = useAuth();
  const [inviteEmail, setInviteEmail] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const sendInvitationMutation = trpc.team.sendInvitation.useMutation({
    onSuccess: () => {
      toast.success("Invitation sent successfully!");
      setInviteEmail("");
    },
    onError: (err) => {
      toast.error((err as any).message || "Failed to send invitation");
    },
  });

  const membersQuery = trpc.team.getMembers.useQuery();
  const invitationsQuery = trpc.team.getInvitations.useQuery();

  const handleSendInvitation = async () => {
    if (!inviteEmail.trim()) {
      toast.error("Please enter an email address");
      return;
    }
    setIsLoading(true);
    try {
      await sendInvitationMutation.mutateAsync({ athleteEmail: inviteEmail });
    } finally {
      setIsLoading(false);
    }
  };

  const isPro = (user as any)?.plan === "pro" || (user as any)?.plan === "team";

  return (
    <SwingLayout>
      <div className="min-h-screen bg-gradient-to-b from-background to-background/50 p-4 md:p-8">
        <div className="max-w-6xl mx-auto space-y-8">
          {/* Header */}
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <Users className="w-6 h-6 text-primary" />
              <h1 className="text-3xl md:text-4xl font-bold text-foreground">Team Management</h1>
            </div>
            <p className="text-muted-foreground">Invite athletes and manage your team</p>
          </div>

          {!isPro ? (
            /* Free tier message */
            <Card className="border-primary/20 bg-primary/5">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Badge variant="outline" className="bg-primary/10">Pro Feature</Badge>
                  Team Management
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-muted-foreground">
                  Team management is available on the Pro and Team plans. Upgrade to invite athletes, manage team members, and leave timestamped comments on swing frames.
                </p>
                <Button className="w-full bg-primary hover:bg-primary/90">
                  Upgrade to Pro
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-6 md:grid-cols-2">
              {/* Invite Athletes */}
              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Mail className="w-4 h-4 text-primary" />
                    Invite Athletes
                  </CardTitle>
                  <CardDescription>Send invitations to join your team</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-foreground">Athlete Email</label>
                    <Input
                      type="email"
                      placeholder="athlete@example.com"
                      value={inviteEmail}
                      onChange={(e) => setInviteEmail(e.target.value)}
                      disabled={isLoading}
                      className="bg-background/50 border-border/50"
                    />
                  </div>
                  <Button
                    onClick={handleSendInvitation}
                    disabled={isLoading || !inviteEmail.trim()}
                    className="w-full bg-primary hover:bg-primary/90"
                  >
                    {isLoading ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Sending...
                      </>
                    ) : (
                      "Send Invitation"
                    )}
                  </Button>
                </CardContent>
              </Card>

              {/* Team Members */}
              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="w-4 h-4 text-primary" />
                    Team Members ({membersQuery.data?.length ?? 0})
                  </CardTitle>
                  <CardDescription>Athletes on your team</CardDescription>
                </CardHeader>
                <CardContent>
                  {membersQuery.isLoading ? (
                    <div className="flex items-center justify-center py-8">
                      <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />
                    </div>
                  ) : membersQuery.data && membersQuery.data.length > 0 ? (
                    <div className="space-y-2">
                      {membersQuery.data.map((member: any) => (
                        <div
                          key={member.id}
                          className="flex items-center justify-between p-3 rounded-lg bg-background/50 border border-border/30"
                        >
                          <div>
                            <p className="text-sm font-medium text-foreground">{member.name}</p>
                            <p className="text-xs text-muted-foreground">{member.email}</p>
                          </div>
                          <Check className="w-4 h-4 text-green-500" />
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-sm text-muted-foreground text-center py-8">
                      No team members yet. Invite athletes to get started.
                    </p>
                  )}
                </CardContent>
              </Card>

              {/* Pending Invitations */}
              <Card className="border-border/50 md:col-span-2">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Mail className="w-4 h-4 text-primary" />
                    Pending Invitations ({invitationsQuery.data?.length ?? 0})
                  </CardTitle>
                  <CardDescription>Athletes who have been invited but haven't joined yet</CardDescription>
                </CardHeader>
                <CardContent>
                  {invitationsQuery.isLoading ? (
                    <div className="flex items-center justify-center py-8">
                      <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />
                    </div>
                  ) : invitationsQuery.data && invitationsQuery.data.length > 0 ? (
                    <div className="space-y-2">
                      {invitationsQuery.data.map((inv: any) => (
                        <div
                          key={inv.id}
                          className="flex items-center justify-between p-3 rounded-lg bg-background/50 border border-border/30"
                        >
                          <div>
                            <p className="text-sm font-medium text-foreground">{inv.email}</p>
                            <p className="text-xs text-muted-foreground">Invited {new Date(inv.createdAt).toLocaleDateString()}</p>
                          </div>
                          <Badge variant="outline" className="bg-yellow-500/10 text-yellow-600 border-yellow-500/20">
                            Pending
                          </Badge>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-sm text-muted-foreground text-center py-8">
                      No pending invitations.
                    </p>
                  )}
                </CardContent>
              </Card>

              {/* Frame Comments Info */}
              <Card className="border-border/50 md:col-span-2 bg-primary/5 border-primary/20">
                <CardHeader>
                  <CardTitle className="text-base">Timestamped Frame Comments</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p className="text-sm text-muted-foreground">
                    As a Team plan coach, you can leave timestamped comments on specific frames of athlete swing videos. This helps provide detailed, frame-by-frame feedback on technique.
                  </p>
                  <ul className="text-sm text-muted-foreground space-y-2 ml-4">
                    <li>• Click on any frame in the Analysis view to add a comment</li>
                    <li>• Comments are timestamped to the exact frame</li>
                    <li>• Athletes can view all coach comments on their sessions</li>
                    <li>• Use comments to highlight specific technique improvements</li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </div>
    </SwingLayout>
  );
}

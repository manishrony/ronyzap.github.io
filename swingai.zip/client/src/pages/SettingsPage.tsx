import { useState, useEffect } from "react";
import { useSearch } from "wouter";
import { motion } from "framer-motion";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import SwingLayout from "@/components/SwingLayout";
import { toast } from "sonner";
import { User, CreditCard, Bell, Check, Crown, ChevronRight, Zap, Shield, Loader2 } from "lucide-react";

const tabs = [
  { id: "profile", label: "Profile", icon: User },
  { id: "billing", label: "Billing & Plans", icon: CreditCard },
  { id: "notifications", label: "Notifications", icon: Bell },
];

const plans = [
  {
    name: "Free",
    description: "Get started with basic swing analysis.",
    features: ["3 analyses/month", "Bat speed score", "Swing efficiency", "7-day history"],
    highlight: false,
    badge: null,
    planKey: "free",
  },
  {
    name: "Pro",
    description: "Unlimited analyses with full AI feedback.",
    features: ["Unlimited analyses", "Hip rotation analysis", "Bat lag timing", "Progress charts", "Skill badges & streaks", "Priority support"],
    highlight: true,
    badge: "Most Popular",
    planKey: "pro",
  },
  {
    name: "Team",
    description: "For coaches managing multiple athletes.",
    features: ["Everything in Pro", "Up to 20 athletes", "Team dashboard", "Comparative analysis", "CSV export", "Account manager"],
    highlight: false,
    badge: "For Coaches",
    planKey: "team",
  },
];

export default function SettingsPage() {
  const search = useSearch();
  const params = new URLSearchParams(search);
  const defaultTab = params.get("tab") ?? "profile";
  const [activeTab, setActiveTab] = useState(defaultTab);
  const { user } = useAuth();
  const isPro = (user as any)?.plan === "pro" || (user as any)?.plan === "team";
  const currentPlan = (user as any)?.plan ?? "free";
  const [tokenCode, setTokenCode] = useState("");
  const [isRedeeming, setIsRedeeming] = useState(false);

  const redeemMutation = trpc.auth.redeemTokenCode.useMutation({
    onSuccess: (result) => {
      if (result.success) {
        toast.success(`Upgraded to ${result.plan} plan!`);
        setTokenCode("");
        window.location.reload();
      } else {
        toast.error(result.error || "Invalid token code");
      }
      setIsRedeeming(false);
    },
    onError: (err) => {
      toast.error("Failed to redeem token code");
      setIsRedeeming(false);
    },
  });

  useEffect(() => {
    const p = new URLSearchParams(window.location.search);
    const t = p.get("tab");
    if (t) setActiveTab(t);
  }, [search]);

  const handleRedeemToken = async () => {
    if (!tokenCode.trim()) {
      toast.error("Please enter a token code");
      return;
    }
    setIsRedeeming(true);
    redeemMutation.mutate({ code: tokenCode });
  };

  return (
    <SwingLayout>
      <div className="max-w-4xl mx-auto space-y-6">
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
          <h1 className="font-display text-2xl lg:text-3xl font-bold text-foreground mb-1">Settings</h1>
          <p className="text-muted-foreground">Manage your account, subscription, and preferences.</p>
        </motion.div>

        <div className="flex gap-1 bg-card border border-white/5 rounded-xl p-1 w-fit">
          {tabs.map(({ id, label, icon: Icon }) => (
            <button key={id} onClick={() => setActiveTab(id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                activeTab === id
                  ? "bg-primary/15 text-primary"
                  : "text-muted-foreground hover:text-foreground"
              }`}>
              <Icon className="w-4 h-4" />
              <span className="hidden sm:inline">{label}</span>
            </button>
          ))}
        </div>

        {/* Profile tab */}
        {activeTab === "profile" && (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
            className="space-y-4">
            <div className="bg-card border border-white/5 rounded-2xl p-6 space-y-5">
              <h2 className="font-display font-semibold text-foreground">Profile Information</h2>

              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-2xl bg-primary/20 flex items-center justify-center">
                  <span className="font-display font-bold text-2xl text-primary">
                    {user?.name?.charAt(0).toUpperCase() ?? "?"}
                  </span>
                </div>
                <div>
                  <p className="font-semibold text-foreground">{user?.name ?? "Athlete"}</p>
                  <p className="text-sm text-muted-foreground">{user?.email ?? "No email"}</p>
                  <Badge className={`mt-1 text-xs ${isPro ? "bg-primary/20 text-primary border-primary/30" : "bg-muted text-muted-foreground border-border"}`}>
                    {isPro ? "Pro Plan" : "Free Plan"}
                  </Badge>
                </div>
              </div>

              <Separator className="bg-border" />

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label className="text-sm text-foreground">Display Name</Label>
                  <Input defaultValue={user?.name ?? ""} placeholder="Your name"
                    className="h-10 bg-secondary/30 border-border text-foreground placeholder:text-muted-foreground" />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-sm text-foreground">Email</Label>
                  <Input defaultValue={user?.email ?? ""} type="email" placeholder="your@email.com"
                    className="h-10 bg-secondary/30 border-border text-foreground placeholder:text-muted-foreground" />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-sm text-foreground">Sport</Label>
                  <Input defaultValue="Baseball" placeholder="Baseball / Softball"
                    className="h-10 bg-secondary/30 border-border text-foreground placeholder:text-muted-foreground" />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-sm text-foreground">Position</Label>
                  <Input placeholder="e.g. Outfielder, Catcher"
                    className="h-10 bg-secondary/30 border-border text-foreground placeholder:text-muted-foreground" />
                </div>
              </div>

              <Button onClick={() => toast.success("Profile updated!")}
                className="bg-primary text-primary-foreground hover:bg-primary/90">
                Save Changes
              </Button>
            </div>

            <div className="bg-card border border-white/5 rounded-2xl p-6">
              <h2 className="font-display font-semibold text-foreground mb-4">Security</h2>
              <div className="flex items-center justify-between p-3 bg-secondary/20 rounded-xl">
                <div className="flex items-center gap-3">
                  <Shield className="w-4 h-4 text-primary" />
                  <div>
                    <p className="text-sm font-medium text-foreground">Authentication</p>
                    <p className="text-xs text-muted-foreground">Managed via Manus OAuth</p>
                  </div>
                </div>
                <Badge className="bg-primary/15 text-primary border-primary/20 text-xs">Active</Badge>
              </div>
            </div>
          </motion.div>
        )}

        {/* Billing tab */}
        {activeTab === "billing" && (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
            {/* Current plan */}
            <div className="bg-card border border-white/5 rounded-2xl p-5">
              <h2 className="font-display font-semibold text-foreground mb-4">Current Plan</h2>
              <div className="flex items-center justify-between p-4 bg-secondary/20 rounded-xl">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${isPro ? "bg-primary/20" : "bg-muted"}`}>
                    {isPro ? <Crown className="w-5 h-5 text-primary" /> : <Zap className="w-5 h-5 text-muted-foreground" />}
                  </div>
                  <div>
                    <p className="font-semibold text-foreground capitalize">{currentPlan} Plan</p>
                    <p className="text-xs text-muted-foreground">{isPro ? "Full access to all features" : "3 analyses per month"}</p>
                  </div>
                </div>
                <Badge className={`${isPro ? "bg-primary/20 text-primary border-primary/30" : "bg-muted text-muted-foreground border-border"}`}>
                  {isPro ? "Active" : "Free"}
                </Badge>
              </div>
            </div>

            {/* Token code redemption */}
            {!isPro && (
              <div className="bg-primary/5 border border-primary/20 rounded-2xl p-5">
                <h2 className="font-display font-semibold text-foreground mb-4 flex items-center gap-2">
                  <Crown className="w-4 h-4 text-primary" />
                  Redeem Token Code
                </h2>
                <p className="text-sm text-muted-foreground mb-4">Have a token code? Enter it below to unlock Pro or Team features.</p>
                <div className="flex gap-2">
                  <Input
                    value={tokenCode}
                    onChange={(e) => setTokenCode(e.target.value)}
                    placeholder="Enter token code..."
                    className="h-11 bg-secondary/30 border-border text-foreground placeholder:text-muted-foreground focus:border-primary"
                    onKeyDown={(e) => e.key === "Enter" && handleRedeemToken()}
                  />
                  <Button
                    onClick={handleRedeemToken}
                    disabled={isRedeeming || !tokenCode.trim()}
                    className="bg-primary text-primary-foreground hover:bg-primary/90 shrink-0">
                    {isRedeeming ? <Loader2 className="w-4 h-4 animate-spin" /> : "Redeem"}
                  </Button>
                </div>
              </div>
            )}

            {/* Plan comparison */}
            <div>
              <h2 className="font-display font-semibold text-foreground mb-4">Available Plans</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {plans.map((plan) => (
                  <div key={plan.name}
                    className={`relative rounded-2xl p-5 border transition-all ${
                      plan.highlight
                        ? "border-primary/40 bg-primary/5"
                        : "border-white/5 bg-card"
                    } ${currentPlan === plan.planKey ? "ring-1 ring-primary/50" : ""}`}>

                    {plan.badge && (
                      <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                        <Badge className={`text-xs px-2.5 py-0.5 ${plan.highlight ? "bg-primary text-primary-foreground" : "bg-secondary text-secondary-foreground"}`}>
                          {plan.badge}
                        </Badge>
                      </div>
                    )}

                    <div className="mb-4">
                      <h3 className="font-display font-bold text-lg text-foreground">{plan.name}</h3>
                      <p className="text-xs text-muted-foreground mt-1">{plan.description}</p>
                    </div>

                    {currentPlan === plan.planKey ? (
                      <div className="w-full mb-4 py-2 px-3 rounded-lg bg-primary/15 text-primary text-sm font-medium text-center">
                        Current Plan
                      </div>
                    ) : (
                      <p className="text-xs text-muted-foreground text-center mb-4">
                        Unlock with token code
                      </p>
                    )}

                    <div className="space-y-2">
                      {plan.features.map((f) => (
                        <div key={f} className="flex items-center gap-2">
                          <Check className="w-3.5 h-3.5 text-primary shrink-0" />
                          <span className="text-xs text-foreground/80">{f}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        )}

        {/* Notifications tab */}
        {activeTab === "notifications" && (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
            className="bg-card border border-white/5 rounded-2xl p-6 space-y-4">
            <h2 className="font-display font-semibold text-foreground">Notification Preferences</h2>
            {[
              { label: "Analysis Complete", description: "Get notified when your swing analysis is ready", default: true },
              { label: "Weekly Progress Report", description: "Receive a weekly summary of your improvement", default: true },
              { label: "Streak Reminders", description: "Reminders to maintain your training streak", default: false },
              { label: "New Feature Announcements", description: "Be the first to know about new SwingAI features", default: false },
            ].map(({ label, description, default: def }) => (
              <div key={label} className="flex items-center justify-between p-4 bg-secondary/20 rounded-xl">
                <div>
                  <p className="text-sm font-medium text-foreground">{label}</p>
                  <p className="text-xs text-muted-foreground">{description}</p>
                </div>
                <button
                  onClick={() => toast.success("Preference saved!")}
                  className={`relative w-10 h-5 rounded-full transition-colors ${def ? "bg-primary" : "bg-secondary"}`}>
                  <div className={`absolute top-0.5 w-4 h-4 rounded-full bg-white transition-transform ${def ? "translate-x-5" : "translate-x-0.5"}`} />
                </button>
              </div>
            ))}
            <Button onClick={() => toast.success("Notification preferences saved!")}
              className="bg-primary text-primary-foreground hover:bg-primary/90">
              Save Preferences
            </Button>
          </motion.div>
        )}
      </div>
    </SwingLayout>
  );
}

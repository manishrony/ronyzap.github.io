import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(userId: number = 1): TrpcContext {
  const user: AuthenticatedUser = {
    id: userId,
    openId: `user-${userId}`,
    email: `user${userId}@example.com`,
    name: `User ${userId}`,
    loginMethod: "manus",
    role: "user",
    plan: "free",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("auth.redeemTokenCode", () => {
  it("should reject invalid token codes", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.auth.redeemTokenCode({ code: "INVALID-TOKEN" });

    expect(result.success).toBe(false);
    expect(result.error).toBe("Invalid token code");
  });

  it("should reject already-used token codes", async () => {
    // Note: In a real test, we'd seed a used token into the database first
    // This test documents the expected behavior
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    // This would fail in practice if a token was already redeemed
    const result = await caller.auth.redeemTokenCode({ code: "ALREADY-USED-TOKEN" });

    expect(result.success).toBe(false);
    expect(result.error).toMatch(/Invalid token code|already used/i);
  });

  it("should reject expired token codes", async () => {
    // Note: In a real test, we'd seed an expired token into the database first
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.auth.redeemTokenCode({ code: "EXPIRED-TOKEN" });

    expect(result.success).toBe(false);
    expect(result.error).toMatch(/Invalid token code|expired/i);
  });

  it("should require authentication", async () => {
    // Create a context without a user (public procedure)
    const ctx: TrpcContext = {
      user: null,
      req: { protocol: "https", headers: {} } as TrpcContext["req"],
      res: {} as TrpcContext["res"],
    };

    const caller = appRouter.createCaller(ctx);

    try {
      await caller.auth.redeemTokenCode({ code: "VALID-TOKEN" });
      expect.fail("Should have thrown an error for unauthenticated user");
    } catch (err) {
      expect(err).toBeDefined();
    }
  });
});

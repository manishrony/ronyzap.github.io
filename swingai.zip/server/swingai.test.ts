import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import { COOKIE_NAME } from "../shared/const";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(plan: "free" | "pro" | "team" = "free"): { ctx: TrpcContext; clearedCookies: { name: string; options: Record<string, unknown> }[] } {
  const clearedCookies: { name: string; options: Record<string, unknown> }[] = [];

  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user-001",
    email: "athlete@example.com",
    name: "Test Athlete",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: (name: string, options: Record<string, unknown>) => {
        clearedCookies.push({ name, options });
      },
    } as TrpcContext["res"],
  };

  return { ctx, clearedCookies };
}

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: () => {} } as TrpcContext["res"],
  };
}

// ─── Auth Tests ───────────────────────────────────────────────────────────────
describe("auth.logout", () => {
  it("clears the session cookie and reports success", async () => {
    const { ctx, clearedCookies } = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.auth.logout();
    expect(result).toEqual({ success: true });
    expect(clearedCookies).toHaveLength(1);
    expect(clearedCookies[0]?.name).toBe(COOKIE_NAME);
    expect(clearedCookies[0]?.options).toMatchObject({ maxAge: -1 });
  });

  it("returns null for unauthenticated me query", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.auth.me();
    expect(result).toBeNull();
  });

  it("returns user for authenticated me query", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.auth.me();
    expect(result).not.toBeNull();
    expect(result?.name).toBe("Test Athlete");
    expect(result?.email).toBe("athlete@example.com");
  });
});

// ─── Mock AI Analysis Logic Tests ────────────────────────────────────────────
describe("Mock AI Analysis", () => {
  it("generates bat speed score between 55 and 95", () => {
    const scores: number[] = [];
    for (let i = 0; i < 100; i++) {
      const score = Math.round(55 + Math.random() * 40);
      scores.push(score);
    }
    scores.forEach(s => {
      expect(s).toBeGreaterThanOrEqual(55);
      expect(s).toBeLessThanOrEqual(95);
    });
  });

  it("generates swing efficiency between 60 and 95", () => {
    const scores: number[] = [];
    for (let i = 0; i < 100; i++) {
      scores.push(Math.round(60 + Math.random() * 35));
    }
    scores.forEach(s => {
      expect(s).toBeGreaterThanOrEqual(60);
      expect(s).toBeLessThanOrEqual(95);
    });
  });

  it("overall score is average of four metrics", () => {
    const batSpeed = 80;
    const swingEfficiency = 75;
    const hipRotation = 85;
    const batLagScore = 70;
    const expected = Math.round((batSpeed + swingEfficiency + hipRotation + batLagScore) / 4);
    expect(expected).toBe(78);
  });

  it("generates hip rotation note for below-optimal rotation", () => {
    const hipRotation = 70; // below 85 optimal
    const hipDiff = hipRotation - 85;
    const note = hipDiff < 0
      ? `Your hip rotation is ${Math.abs(hipDiff)}% below optimal.`
      : `Hip rotation is strong at ${hipRotation}%.`;
    expect(note).toContain("below optimal");
    expect(note).toContain("15%");
  });

  it("generates bat lag note for low bat lag score", () => {
    const batLagScore = 60; // below 70 threshold
    const note = batLagScore < 70
      ? `Bat lag timing needs improvement.`
      : `Excellent bat lag at ${batLagScore}/100.`;
    expect(note).toContain("needs improvement");
  });

  it("generates positive bat lag note for high score", () => {
    const batLagScore = 88;
    const note = batLagScore < 70
      ? `Bat lag timing needs improvement.`
      : `Excellent bat lag at ${batLagScore}/100.`;
    expect(note).toContain("Excellent bat lag");
  });
});

// ─── Pricing Tier Logic Tests ─────────────────────────────────────────────────
describe("Plan gating logic", () => {
  it("free plan has limited analyses", () => {
    const FREE_LIMIT = 3;
    expect(FREE_LIMIT).toBe(3);
  });

  it("pro plan identifier is correct", () => {
    const plan = "pro";
    const isPro = plan === "pro" || plan === "team";
    expect(isPro).toBe(true);
  });

  it("team plan is treated as pro", () => {
    const plan = "team";
    const isPro = plan === "pro" || plan === "team";
    expect(isPro).toBe(true);
  });

  it("free plan is not pro", () => {
    const plan = "free";
    const isPro = plan === "pro" || plan === "team";
    expect(isPro).toBe(false);
  });
});

// ─── Gamification Logic Tests ─────────────────────────────────────────────────
describe("Gamification / Badge logic", () => {
  it("streak is capped at 7 days", () => {
    const sessionsCount = 15;
    const streak = Math.min(sessionsCount, 7);
    expect(streak).toBe(7);
  });

  it("streak equals session count when below 7", () => {
    const sessionsCount = 4;
    const streak = Math.min(sessionsCount, 7);
    expect(streak).toBe(4);
  });

  it("speed demon badge requires bat speed >= 70", () => {
    const avgBatSpeed = 72;
    const earned = avgBatSpeed >= 70;
    expect(earned).toBe(true);
  });

  it("speed demon badge not earned below 70", () => {
    const avgBatSpeed = 65;
    const earned = avgBatSpeed >= 70;
    expect(earned).toBe(false);
  });

  it("first swing badge earned after 1 session", () => {
    const sessionsCount = 1;
    const earned = sessionsCount >= 1;
    expect(earned).toBe(true);
  });
});

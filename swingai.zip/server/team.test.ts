import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(userId: number = 1, plan: string = "team"): TrpcContext {
  const user: AuthenticatedUser = {
    id: userId,
    openId: `user-${userId}`,
    email: `user${userId}@example.com`,
    name: `User ${userId}`,
    loginMethod: "manus",
    role: "user",
    plan: plan as any,
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("team management", () => {
  it("should reject invitation from non-team users", async () => {
    const ctx = createAuthContext(1, "free");
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.team.sendInvitation({ athleteEmail: "athlete@example.com" });
      expect.fail("Should have thrown an error");
    } catch (err) {
      expect((err as any).message).toContain("Only Team plan users");
    }
  });

  it("should allow team users to send invitations", async () => {
    const ctx = createAuthContext(1, "team");
    const caller = appRouter.createCaller(ctx);

    const result = await caller.team.sendInvitation({ athleteEmail: "athlete@example.com" });
    expect(result.success).toBe(true);
  });

  it("should allow team users to get team members", async () => {
    const ctx = createAuthContext(1, "team");
    const caller = appRouter.createCaller(ctx);

    const members = await caller.team.getMembers();
    expect(Array.isArray(members)).toBe(true);
  });

  it("should return empty array for non-team users getting members", async () => {
    const ctx = createAuthContext(1, "free");
    const caller = appRouter.createCaller(ctx);

    const members = await caller.team.getMembers();
    expect(members).toEqual([]);
  });
});

describe("frame comments", () => {
  it("should reject comments from non-team users", async () => {
    const ctx = createAuthContext(1, "free");
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.comments.add({ sessionId: 1, timestamp: 5.0, comment: "Test comment" });
      expect.fail("Should have thrown an error");
    } catch (err) {
      expect((err as any).message).toContain("Only Team plan users");
    }
  });

  it("should allow team users to add comments", async () => {
    const ctx = createAuthContext(1, "team");
    const caller = appRouter.createCaller(ctx);

    const result = await caller.comments.add({ sessionId: 1, timestamp: 5.0, comment: "Great swing!" });
    expect(result.success).toBe(true);
  });

  it("should allow team users to get comments", async () => {
    const ctx = createAuthContext(1, "team");
    const caller = appRouter.createCaller(ctx);

    const comments = await caller.comments.getBySession({ sessionId: 1 });
    expect(Array.isArray(comments)).toBe(true);
  });
});

import { eq, desc, and } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, swingSessions, swingAnalyses, InsertSwingSession, InsertSwingAnalysis, tokenCodes } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) { console.warn("[Database] Cannot upsert user: database not available"); return; }
  try {
    const values: InsertUser = { openId: user.openId };
    const updateSet: Record<string, unknown> = {};
    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];
    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };
    textFields.forEach(assignNullable);
    if (user.lastSignedIn !== undefined) { values.lastSignedIn = user.lastSignedIn; updateSet.lastSignedIn = user.lastSignedIn; }
    if (user.role !== undefined) { values.role = user.role; updateSet.role = user.role; }
    else if (user.openId === ENV.ownerOpenId) { values.role = 'admin'; updateSet.role = 'admin'; }
    if (!values.lastSignedIn) values.lastSignedIn = new Date();
    if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
    await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ─── Swing Sessions ──────────────────────────────────────────────────

export async function createSwingSession(data: InsertSwingSession) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(swingSessions).values(data);
  return result;
}

export async function getSwingSessionsByUser(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(swingSessions).where(eq(swingSessions.userId, userId)).orderBy(desc(swingSessions.createdAt));
}

export async function getSwingSessionById(id: number, userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(swingSessions)
    .where(and(eq(swingSessions.id, id), eq(swingSessions.userId, userId))).limit(1);
  return result[0];
}

export async function updateSwingSessionStatus(id: number, status: "pending" | "processing" | "completed" | "failed", videoUrl?: string, videoKey?: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const updateData: Record<string, unknown> = { status };
  if (videoUrl) updateData.videoUrl = videoUrl;
  if (videoKey) updateData.videoKey = videoKey;
  await db.update(swingSessions).set(updateData).where(eq(swingSessions.id, id));
}

// ─── Swing Analyses ──────────────────────────────────────────────────

export async function createSwingAnalysis(data: InsertSwingAnalysis) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(swingAnalyses).values(data);
}

export async function getAnalysisBySession(sessionId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(swingAnalyses).where(eq(swingAnalyses.sessionId, sessionId)).limit(1);
  return result[0];
}

export async function getAnalysesByUser(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(swingAnalyses).where(eq(swingAnalyses.userId, userId)).orderBy(desc(swingAnalyses.createdAt));
}

// ─── Token Codes ────────────────────────────────────────────────────────

export async function validateAndApplyTokenCode(code: string, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.select().from(tokenCodes).where(eq(tokenCodes.code, code)).limit(1);
  const token = result[0];

  if (!token) return { success: false, error: "Invalid token code" };
  if (token.usedBy) return { success: false, error: "Token code already used" };
  if (token.expiresAt && token.expiresAt < new Date()) return { success: false, error: "Token code expired" };

  // Mark token as used and update user plan
  await db.update(tokenCodes).set({ usedBy: userId, usedAt: new Date() }).where(eq(tokenCodes.id, token.id));
  await db.update(users).set({ plan: token.plan }).where(eq(users.id, userId));

  return { success: true, plan: token.plan };
}

// ─── Team Management ────────────────────────────────────────────────────

export async function sendTeamInvitation(coachId: number, athleteEmail: string) {
  // Mock implementation - in production, send email invitation
  console.log(`Invitation sent from coach ${coachId} to ${athleteEmail}`);
  return { success: true };
}

export async function getTeamInvitations(email: string) {
  // Mock implementation - return empty list
  return [];
}

export async function acceptTeamInvitation(invitationId: number, userId: number) {
  // Mock implementation
  console.log(`User ${userId} accepted invitation ${invitationId}`);
  return { success: true };
}

export async function getTeamMembers(coachId: number) {
  // Mock implementation - return empty list
  return [];
}

export async function getCoachTeams(athleteId: number) {
  // Mock implementation - return empty list
  return [];
}

// ─── Frame Comments ────────────────────────────────────────────────────

export async function addFrameComment(sessionId: number, userId: number, timestamp: number, comment: string) {
  // Mock implementation
  console.log(`Comment added to session ${sessionId} at ${timestamp}s: ${comment}`);
  return { success: true };
}

export async function getFrameComments(sessionId: number) {
  // Mock implementation - return empty list
  return [];
}

export async function deleteFrameComment(commentId: number, userId: number) {
  // Mock implementation
  console.log(`Comment ${commentId} deleted by user ${userId}`);
  return { success: true };
}

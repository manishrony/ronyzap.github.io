import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import {
  createSwingSession, getSwingSessionsByUser, getSwingSessionById,
  updateSwingSessionStatus, createSwingAnalysis, getAnalysisBySession, getAnalysesByUser,
  validateAndApplyTokenCode, sendTeamInvitation, getTeamInvitations, acceptTeamInvitation,
  getTeamMembers, getCoachTeams, addFrameComment, getFrameComments, deleteFrameComment
} from "./db";
import { storagePut } from "./storage";
import { nanoid } from "nanoid";

// ─── Mock AI Analysis Generator ──────────────────────────────────────
function generateMockAnalysis(sessionId: number, userId: number) {
  const batSpeed = Math.round(55 + Math.random() * 40);
  const swingEfficiency = Math.round(60 + Math.random() * 35);
  const hipRotation = Math.round(65 + Math.random() * 30);
  const batLagScore = Math.round(50 + Math.random() * 45);
  const overallScore = Math.round((batSpeed + swingEfficiency + hipRotation + batLagScore) / 4);

  const hipDiff = hipRotation - 85;
  const hipNote = hipDiff < 0
    ? `Your hip rotation is ${Math.abs(hipDiff)}% below optimal. Focus on initiating the swing with your hips before your hands.`
    : `Hip rotation is strong at ${hipRotation}%. Maintain this explosive hip drive.`;

  const batLagNote = batLagScore < 70
    ? `Bat lag timing needs improvement. Your barrel is releasing ${Math.round((80 - batLagScore) * 0.3)}ms too early — work on maintaining wrist cock through the contact zone.`
    : `Excellent bat lag at ${batLagScore}/100. Your late barrel release is generating maximum power.`;

  const bodyNotes = [
    batSpeed < 70 ? "Weight transfer from back to front foot is incomplete — ensure full hip extension at contact." : "Weight transfer is efficient and well-timed.",
    swingEfficiency < 75 ? "Slight casting motion detected in the swing path — keep your hands inside the ball." : "Compact swing path with minimal wasted movement.",
    "Shoulder tilt at contact looks good — maintain this spine angle throughout the swing.",
  ].join(" ");

  const recommendations = [
    batSpeed < 70 ? "Tee work focusing on hip-to-hand sequencing (3 sets × 20 reps)" : "Continue bat speed maintenance drills",
    hipRotation < 80 ? "Hip rotation drills with resistance band (daily, 2 sets × 15)" : "Advanced rotational power exercises",
    batLagScore < 70 ? "Wrist lag drills with a weighted bat (2 sets × 10 slow swings)" : "Maintain current bat path training",
    "Video review session recommended to reinforce muscle memory",
  ];

  return {
    sessionId,
    userId,
    batSpeedScore: batSpeed,
    swingEfficiency,
    hipRotation,
    batLagScore,
    bodyPositioningNotes: bodyNotes,
    hipRotationNotes: hipNote,
    batLagNotes: batLagNote,
    overallScore,
    recommendations,
  };
}

export const appRouter = router({
  system: systemRouter,

  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
    redeemTokenCode: protectedProcedure
      .input(z.object({ code: z.string() }))
      .mutation(async ({ ctx, input }) => {
        return validateAndApplyTokenCode(input.code, ctx.user.id);
      }),
  }),

  // ─── Swing Sessions ──────────────────────────────────────────────
  sessions: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return getSwingSessionsByUser(ctx.user.id);
    }),

    get: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ ctx, input }) => {
        return getSwingSessionById(input.id, ctx.user.id);
      }),

    create: protectedProcedure
      .input(z.object({ title: z.string().optional() }))
      .mutation(async ({ ctx, input }) => {
        await createSwingSession({
          userId: ctx.user.id,
          title: input.title ?? "Swing Session",
          status: "pending",
        });
        const sessions = await getSwingSessionsByUser(ctx.user.id);
        return sessions[0];
      }),

    uploadVideo: protectedProcedure
      .input(z.object({
        sessionId: z.number(),
        fileName: z.string(),
        fileData: z.string(), // base64
        mimeType: z.string(),
      }))
      .mutation(async ({ ctx, input }) => {
        const buffer = Buffer.from(input.fileData, "base64");
        const key = `swings/${ctx.user.id}/${input.sessionId}-${nanoid(8)}-${input.fileName}`;
        const { url } = await storagePut(key, buffer, input.mimeType);
        await updateSwingSessionStatus(input.sessionId, "completed", url, key);
        return { url, key };
      }),

    analyze: protectedProcedure
      .input(z.object({ sessionId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const session = await getSwingSessionById(input.sessionId, ctx.user.id);
        if (!session) throw new Error("Session not found");

        // Check if analysis already exists
        const existing = await getAnalysisBySession(input.sessionId);
        if (existing) return existing;

        // Generate mock AI analysis
        const analysisData = generateMockAnalysis(input.sessionId, ctx.user.id);
        await createSwingAnalysis(analysisData);
        const analysis = await getAnalysisBySession(input.sessionId);
        return analysis;
      }),
  }),

  // ─── Analysis ────────────────────────────────────────────────────
  analysis: router({
    getBySession: protectedProcedure
      .input(z.object({ sessionId: z.number() }))
      .query(async ({ ctx, input }) => {
        return getAnalysisBySession(input.sessionId);
      }),

    history: protectedProcedure.query(async ({ ctx }) => {
      return getAnalysesByUser(ctx.user.id);
    }),
  }),

  team: router({
    sendInvitation: protectedProcedure
      .input(z.object({ athleteEmail: z.string().email() }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.plan !== "team") throw new Error("Only Team plan users can invite athletes");
        await sendTeamInvitation(ctx.user.id, input.athleteEmail);
        return { success: true };
      }),

    getInvitations: protectedProcedure.query(async ({ ctx }) => {
      return getTeamInvitations(ctx.user.email || "");
    }),

    acceptInvitation: protectedProcedure
      .input(z.object({ invitationId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await acceptTeamInvitation(input.invitationId, ctx.user.id);
        return { success: true };
      }),

    getMembers: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user.plan !== "team") return [];
      const members = await getTeamMembers(ctx.user.id);
      return members;
    }),

    getCoaches: protectedProcedure.query(async ({ ctx }) => {
      return getCoachTeams(ctx.user.id);
    }),
  }),

  comments: router({
    add: protectedProcedure
      .input(z.object({ sessionId: z.number(), timestamp: z.number(), comment: z.string() }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.plan !== "team") throw new Error("Only Team plan users can add comments");
        await addFrameComment(input.sessionId, ctx.user.id, input.timestamp, input.comment);
        return { success: true };
      }),

    getBySession: protectedProcedure
      .input(z.object({ sessionId: z.number() }))
      .query(async ({ ctx, input }) => {
        return getFrameComments(input.sessionId);
      }),

    delete: protectedProcedure
      .input(z.object({ commentId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.plan !== "team") throw new Error("Only Team plan users can delete comments");
        await deleteFrameComment(input.commentId, ctx.user.id);
        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;

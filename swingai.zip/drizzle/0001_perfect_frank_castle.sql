CREATE TABLE `swing_analyses` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sessionId` int NOT NULL,
	`userId` int NOT NULL,
	`batSpeedScore` float,
	`swingEfficiency` float,
	`hipRotation` float,
	`batLagScore` float,
	`bodyPositioningNotes` text,
	`hipRotationNotes` text,
	`batLagNotes` text,
	`overallScore` float,
	`recommendations` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `swing_analyses_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `swing_sessions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`title` varchar(255) DEFAULT 'Swing Session',
	`videoUrl` text,
	`videoKey` text,
	`status` enum('pending','processing','completed','failed') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `swing_sessions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` ADD `plan` enum('free','pro','team') DEFAULT 'free' NOT NULL;
CREATE TABLE `token_codes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`code` varchar(64) NOT NULL,
	`plan` enum('pro','team') NOT NULL,
	`usedBy` int,
	`usedAt` timestamp,
	`expiresAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `token_codes_id` PRIMARY KEY(`id`),
	CONSTRAINT `token_codes_code_unique` UNIQUE(`code`)
);

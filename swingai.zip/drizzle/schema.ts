import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, float, json } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  plan: mysqlEnum("plan", ["free", "pro", "team"]).default("free").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const swingSessions = mysqlTable("swing_sessions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  title: varchar("title", { length: 255 }).default("Swing Session"),
  videoUrl: text("videoUrl"),
  videoKey: text("videoKey"),
  status: mysqlEnum("status", ["pending", "processing", "completed", "failed"]).default("pending").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const swingAnalyses = mysqlTable("swing_analyses", {
  id: int("id").autoincrement().primaryKey(),
  sessionId: int("sessionId").notNull(),
  userId: int("userId").notNull(),
  batSpeedScore: float("batSpeedScore"),
  swingEfficiency: float("swingEfficiency"),
  hipRotation: float("hipRotation"),
  batLagScore: float("batLagScore"),
  bodyPositioningNotes: text("bodyPositioningNotes"),
  hipRotationNotes: text("hipRotationNotes"),
  batLagNotes: text("batLagNotes"),
  overallScore: float("overallScore"),
  recommendations: json("recommendations"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const tokenCodes = mysqlTable("token_codes", {
  id: int("id").autoincrement().primaryKey(),
  code: varchar("code", { length: 64 }).notNull().unique(),
  plan: mysqlEnum("plan", ["pro", "team"]).notNull(),
  usedBy: int("usedBy"),
  usedAt: timestamp("usedAt"),
  expiresAt: timestamp("expiresAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type SwingSession = typeof swingSessions.$inferSelect;
export type InsertSwingSession = typeof swingSessions.$inferInsert;
export type SwingAnalysis = typeof swingAnalyses.$inferSelect;
export type InsertSwingAnalysis = typeof swingAnalyses.$inferInsert;
export type TokenCode = typeof tokenCodes.$inferSelect;
export type InsertTokenCode = typeof tokenCodes.$inferInsert;

# SwingAI TODO

## Phase 1 — Foundation
- [x] Global dark theme CSS variables and typography
- [x] Database schema: users, swing_sessions, swing_analyses
- [x] tRPC routers for sessions and analysis

## Phase 2 — Landing Page
- [x] Hero section: "Train Smarter with AI" headline + CTA
- [x] Features section (AI Analysis, Progress Tracking, Smart Feedback)
- [x] How It Works 3-step flow
- [x] Testimonials section (mock)
- [x] Pricing section (Free / Pro / Team) with highlighted recommended tier
- [x] Smooth scroll animations (Framer Motion)
- [x] Responsive navbar with logo + CTA

## Phase 3 — Authentication
- [x] Login page with Google/Apple social buttons (UI only)
- [x] Signup page with Google/Apple social buttons (UI only)
- [x] JWT session management via tRPC auth

## Phase 4 — Dashboard
- [x] Dashboard layout with sidebar (Dashboard, Upload, Analysis, Progress, Settings)
- [x] Dashboard home: stats overview, recent sessions, quick actions
- [x] Upload page: drag-and-drop video UI, file preview, submission flow
- [x] Analysis page: video playback, AI feedback (bat speed, swing efficiency, body positioning, hip rotation, bat lag)
- [x] Progress page: Recharts improvement charts, session history log
- [x] Settings page: profile, plan info, notifications

## Phase 5 — AI & Gamification
- [x] Mock AI analysis logic (randomized realistic feedback)
- [x] Bat speed score (0–100)
- [x] Swing efficiency score
- [x] Body positioning notes
- [x] Hip rotation percentage
- [x] Bat lag timing feedback
- [x] Skill level badges
- [x] Streak tracking
- [x] Locked feature UI with "Upgrade to Pro" prompts

## Phase 6 — Polish
- [x] Fully responsive mobile + desktop layout
- [x] Micro-interactions and Framer Motion transitions
- [x] Vitest unit tests (19 passing)
- [x] Final checkpoint

## Post-Launch Updates
- [x] Update company name to "Ronyzap LLC" in footer, legal copy, and about pages
- [x] Replace Stripe billing with token code system
- [x] Add token code input field to Settings/Billing page
- [x] Create tRPC procedure to validate and apply token codes
- [x] Update user plan tier based on token code validity

## Team/Coach Features (New)
- [x] Database tables: teams, team_members, team_invitations, frame_comments
- [x] tRPC team routers: sendInvitation, getMembers, getInvitations, acceptInvitation
- [x] tRPC comment routers: add, getBySession, delete
- [x] Team Dashboard page with invite UI and member list
- [x] Team nav item (Pro/Team only) in sidebar
- [x] Team-only feature gating (Pro/Team plan check)
